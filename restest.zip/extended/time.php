<?php
require "headerbg.php";
echo '<center>Раздел `Обща статистика`<center/>';
$count_data = $pdo->query("SELECT id FROM gros_stat ORDER BY id");
$count = 0;
$last = -1;
//--------------------->
$domain = array();
$statement1 = $pdo->query("SELECT * FROM domains s, emotions sc WHERE sc.domain_id = s.id ");
while($row = $statement1->fetch(PDO::FETCH_BOTH))
{
	$domain[$row['id']] = $row['domain_id'];
	
}
//--------------------->
$id_array = array();
while($r = $count_data->fetch(PDO::FETCH_BOTH))
{
	if($r['id'] != $last)
	{
		$last = $r['id'];
		$id_array[] = $last;
		$count++;
	}
}
echo '<table class="borders">';
echo '<tr>
<th>№</th>
<th>Начало</th>
<th>Край</th>
</tr>';
//<th>Общо</th>
for($k = 0; $k<$count; $k++)
{ 
$current_id = $id_array[$k];

	$sel_emotions = $pdo->query("SELECT * FROM choice_stat WHERE id=$current_id LIMIT 1");
	while($r = $sel_emotions->fetch(PDO::FETCH_BOTH)){
		$start=$r['end'];
		
		$data = $pdo->query("SELECT time FROM miniscripts_stat WHERE id = $current_id LIMIT 1");
		$r = $data->fetch(PDO::FETCH_BOTH);
		$stress = $r['time'];	
		
		$data = $pdo->query("SELECT timing FROM gros_stat WHERE id = $current_id LIMIT 1");
		$r = $data->fetch(PDO::FETCH_BOTH);
		$end = $r['timing'];
		
		
	}

	$datetime1 = new DateTime($start);
	$datetime2 = new DateTime($stress);
	$datetime3 = new DateTime($end);

	if(isset($id)) {
		$interval = $datetime1->diff($datetime3);
	}
	else {
		$interval = $datetime1->diff($datetime2);
	}
//---------------------------->
		echo '<tr><td><center>'.$current_id.'</center></td>
		<td>'.$start.'</td>
		<td>'.$end.'</td>
		
		</tr>';
		/*
		<td>'.$interval->format('%H:%i:%s').'</td>		
		*/
}
echo '</table>';
require "end.php";
?>