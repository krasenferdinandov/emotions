<?php
date_default_timezone_set("Europe/Sofia");
require_once "constantsbg1.php";
require_once "db_pass1.php";
if (array_key_exists('timeStarted', $_POST))
	{
		echo '<input type="hidden" name="timeStarted" value="'.$_POST['timeStarted'].'">';
	} 
	else
	{
		redirect ('emotionsbg.php');
	}

$data = $pdo->query("SELECT id FROM duration_stat ORDER BY id DESC LIMIT 1");
$r = $data->fetch(PDO::FETCH_BOTH);
$id = $r['id']+1;

for($i = 0; $i<EMOTIONS_NUMBER; $i++){
	if(!isset($_POST['emotion_'.$i])) continue;
	$e_slider = intval($_POST['e_slider_'.$i]);
	validateInt($e_slider);
	$data = $pdo->query("SELECT domain_id FROM feelings WHERE id=$i");
	$row = $data->fetch(PDO::FETCH_BOTH);
	$timing = $_POST['domaintiming_'.$row['domain_id']];
	//echo $i . ' -> ' . $timing . '<br/>';
	//echo $i . ' -> ' . $e_slider . '<br/>';
	$pdo->exec("INSERT INTO duration_stat VALUES ($id,$i,$e_slider,'$timing');");
}
//------> Отчита емоциите при checkbox.
/*for($i = 0; $i<EMOTIONS_NUMBER; $i++){
	if(!isset($_POST['emotion_'.$i])) continue;
	$e_slider = intval($_POST['e_slider_'.$i]);
	validateInt($e_slider);
	$data = $pdo->query("SELECT id FROM feelings WHERE id=$i");
	$row = $data->fetch(PDO::FETCH_BOTH);
	$timing = $_POST['domaintiming_'.$row['id']];
	//echo $i . ' -> ' . $timing . '<br/>';
	//echo $i . ' -> ' . $e_slider . '<br/>';
	$pdo->exec("INSERT INTO duration_stat VALUES ($id,$i,$e_slider,'$timing');");
}*/
$timeStarted = $_POST['timeStarted'];
$pdo->exec("INSERT INTO duration_timing VALUES ($id, '$timeStarted', NOW());");
//------->
echo '<meta http-equiv="Refresh" content="0;themesbg.php?id='.$id.'" />';

//echo '<meta http-equiv="Refresh" content="0;genderbg.php?id='.$id.'" />';
require "end1.php";
?>