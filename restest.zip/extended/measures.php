<?php
require "header.php";
echo '<table class="borders">';
echo '<tr><th>Id</th>';
function interval_to_duration ($interval) {
	return ($interval->h*60 + $interval->i + (floatval($interval->s) / 60));
}
function to_minutes ($duration) {
	return floor($duration) + ($duration - floor($duration)) * 60 / 100;
}
function ed ($category, $total)
{
	if($category>0 && $total > 0)
		return -1*($category/$total)*log($category/$total);
	else
		return 0;
}
function isInDomain($emotion_search){
	return (floor($emotion_search));
}
$string = array();
$domain = array();
$emotions = array();

$label = $pdo->query("SELECT id, en_name, bg_name FROM emotions");
while($row = $label->fetch(PDO::FETCH_BOTH))
{
	$bg_name = $row['en_name'];
	$emotions[$row['id']] ='<a title="'.quot($row['bg_name']).'">'. $bg_name.'</a>';
}

$statement = $pdo->query("SELECT id, string_id FROM emotions");
while($row = $statement->fetch(PDO::FETCH_BOTH))
{
	$string[$row['id']] = $row['string_id'];
		
}

$statement1 = $pdo->query("SELECT * FROM domains s, emotions sc WHERE sc.domain_id = s.id ");
while($row = $statement1->fetch(PDO::FETCH_BOTH))
{
	$domain[$row['id']] = $row['domain_id'];
	
}
for($i=0;$i<DOMAINS_NUMBER;$i++){
	$domain_data = $pdo->query("select en_name, bg_name from domains where id = ". $i . "");
	
	$name = "WRONG";
	while($r = $domain_data->fetch(PDO::FETCH_BOTH))
	{
		$en_name = $r["en_name"];
		$bg_name = $r["bg_name"];
	}
	//echo '<td><center>D'.$i.', '.$en_name.', '.$bg_name.'</center></td>';
	//echo '<td><center>F'.$i.'_'.$en_name.'</center></td>';
	//echo '<td><center>F'.$i.'</center></td>';
}
//------------------>
for($i=0;$i<THEMES_NUMBER;$i++){
	$script_data = $pdo->query("select en_name, bg_name from statements where id = ". $i . "");
		
	$name = "WTF";
	while($r = $script_data->fetch(PDO::FETCH_BOTH))
	{
		$en_name = $r["en_name"];
		$bg_name = $r["bg_name"];
	}
    //echo '<td><center>T'.$i.'_'.$en_name.'</center></td>';
	//echo '<td><center>T'.$i.'</center></td>';
}
for($i=0;$i<MINISCRIPTS_NUMBER;$i++){
	$miniscript_data = $pdo->query("select en_name, bg_name from miniscripts where id = ". $i . "");
		
	$name = "WTF";
	while($r = $miniscript_data->fetch(PDO::FETCH_BOTH))
	{
		$en_name = $r["en_name"];
		$bg_name = $r["bg_name"];
	}
	//echo '<td><center>S'.$i.', '.$en_name.'</center></td>';
	//echo '<td><center>S'.$i.', '.$en_name.', '.$bg_name.'</center></td>';
	//echo '<td><center>S'.$i.'</center></td>';
}
for($i=0;$i<STATES_NUMBER;$i++){
	$script_data = $pdo->query("select en_name, bg_name, axis_id from gros where id = ". $i . "");
		
	$name = "WTF";
	while($r = $script_data->fetch(PDO::FETCH_BOTH))
	{
		$en_name = $r["en_name"];
		$bg_name = $r["bg_name"];
		$axis = $r["axis_id"];
		
		if ($axis == 19){			
		$label= "S";
		}
		else 
		{
		$label= "R";
		}
	}
	//echo '<td><center>'.$label.''.$i.'</center></td>';
}
echo '<td><center><b>1. Време за разпознаване на изражения, в минути (Ekman & Friesen 1975)</b></center></td>';
echo '<td><center><b>2. Време за отчитане на избраните семейства, в минути (Фердинандов 2018)</b></center></td>';
echo '<td><center><b>3. Време за отчитане на избраните отрицателни емоции, в минути (Фердинандов 2018)</b></center></td>';
echo '<td><center><b>4 Време за свързване на теми, в минути (Demorest 2008)</b></center></td>';
echo '<td><center><b>5. Брой свързани сценарии (Tomkins 1978)</b></center></td>';
echo '<td><center><b>6. Време за свързване на сценарии, в минути (Tomkins 1978)</b></center></td>';
echo '<td><center><b>7. Общо време за участие, в минути (Bassili 1996)</b><center></td>';
echo '<td><center><b>8. Ниво на фрустрация (Brown & Farber 1951)</b><center></td>';
echo '<td><center><b>9. Ниво на конфликтите (Kaplan 1972)</b><center></td>';
echo '<td><center><b>10. Потенциално противоречие (Thompson et al. 1995)</b><center></td>';
echo '<td><center><b>11. Изразеност на противоречията (Thompson et al. 1995)</b><center></td>';
echo '<td><center><b>12. Ниво на  преживяна фрустрация, с градиращ праг (Priester & Petty 1996)</b><center></td>';
echo '<td><center><b>13. Ниво на  преживяна фрустрация, с рязък праг (Priester & Petty 1996)</b><center></td>';
echo '<td><center><b>14. Преживяно нещастие (Juster et al. 1985, Kahneman et al. 2006)</b><center></td>';
echo '<td><center><b>25. Индекс на нещастието (Фердинандов 2019)</b><center></td>';
echo '</tr>';

$count_data = $pdo->query("SELECT id FROM states_stat ORDER BY id");

$count = 0;
$last = -1;
$id_array = array();
while($r = $count_data->fetch(PDO::FETCH_BOTH))
{
	if($r['id'] != $last)
	{
		$last = $r['id'];
		$id_array[] = $last;
		$count++;
	}
}

for($k = 0; $k<$count; $k++)
{ 
	$current_id = $id_array[$k];
	$emotion_row_array = array();
	$domain_row_array = array();
	$miniscripts_row_array = array();
	$scripts_row_array = array();
	
//$data = $pdo->query("SELECT * FROM emotions_stat WHERE id = $current_id LIMIT 1");
//$data = $pdo->query("SELECT * FROM id_stat WHERE id = $current_id LIMIT 1");
//$data = $pdo->query("SELECT * FROM states_stat WHERE id = $current_id LIMIT 1");
$data = $pdo->query("SELECT * FROM gros_stat WHERE id = $current_id LIMIT 1");
//$data = $pdo->query("SELECT * FROM status_stat WHERE id = $current_id LIMIT 1");
$r = $data->fetch(PDO::FETCH_BOTH);
$id = $r['id'];
if(!isset($id)) continue;
	for($i = 0; $i<EMOTIONS_NUMBER; $i++)
	{
		$emotion_row_array[] = 0;
	}
	$domains_category_array ['pos'] = array();
	$domains_category_array ['neg'] = array();
	for($i = 0; $i<DOMAINS_NUMBER; $i++)
	{
		$domain_row_array[] = 0;
		$domains_category_array ['pos'][] = 0;
		$domains_category_array ['neg'][] = 0;
	}
	for($i = 0; $i<THEMES_NUMBER; $i++)
	{
		$scripts_row_array[] = 0;
	}
	for($i = 0; $i<MINISCRIPTS_NUMBER; $i++)
	{
		$miniscripts_row_array[] = 0;
	}
	$count_e=0;	
	$data = $pdo->query("SELECT emotion_id FROM emotions_stat WHERE id = $current_id");
	while($r = $data->fetch(PDO::FETCH_BOTH)) {
			
		$e_id = $r['emotion_id'];
		if($e_id!=-1) $emotion_row_array[$e_id] = 1;
		if($e_id != -1)$domain_row_array[$domain[$e_id]] = 1;
		
		$count_e+=1;
	}
$data = $pdo->query("SELECT * FROM gros_stat WHERE id = $current_id LIMIT 1");
$r = $data->fetch(PDO::FETCH_BOTH);
$id = $r['id'];
if(!isset($id)) continue;
	for($i = 0; $i<STATES_NUMBER; $i++)
	{
		$scripts_row_array[] = 0;
	}	
	
	$count_s=0;	
	$data_s = $pdo->query("SELECT * FROM states_stat WHERE id = $current_id");
	while($r = $data_s->fetch(PDO::FETCH_BOTH)) {
		$si_id = $r['state_id'];
				
		if($si_id!=-1) $scripts_row_array[$si_id] = 1;
		$count_s+=1;
	}
	
	$count_m=0;	
	$data = $pdo->query("SELECT miniscript_id FROM miniscripts_stat WHERE id = $current_id");
	while($r = $data->fetch(PDO::FETCH_BOTH)) {
		$mi_id = $r['miniscript_id'];
		if($mi_id!=-1) $miniscripts_row_array[$mi_id] = 1;
		$count_m+=1;
	}
//------------------------>
$posi = '';
$nega = '';
$manag = 0;
$sum_pos=0;$count_pos=0;
$sum_neg=0;$count_neg=0;
$sel_emotions = $pdo->query("SELECT * FROM emotions_stat WHERE id=$current_id");
while($r = $sel_emotions->fetch(PDO::FETCH_BOTH)){
	$e_id=$r['emotion_id'];
	$e_sl=$r['e_slider'];
	
	$data = $pdo->query("SELECT domain_id, valence_id, string_id, tension_id FROM emotions WHERE id = $e_id LIMIT 1");
	$r = $data->fetch(PDO::FETCH_BOTH);
	$domain_id = intval($r['domain_id']);
	$dimension_id = $r['valence_id'];
	$e_string = $r['string_id'];
	$e_tension = $r['tension_id'];
	
		if ($e_string == 0){			
		$density= (($e_sl*0.4)+$e_tension);
		}
		else if($e_string == 1){
		$density=(($e_sl*0.6)+$e_tension);
		}
		else if($e_string == 2){
		$density=(($e_sl*0.8)+$e_tension);
		}

		if($dimension_id == 0){
			$sum_pos+=$e_sl;
			$count_pos+=1;
		}
		if($dimension_id == 1){
			$sum_neg+=$e_sl;
			$count_neg+=1;
		}
}		
$score_neg=scores_level($sum_neg, $count_neg);
$score_pos=scores_level($sum_pos, $count_pos);
$score_group=$score_neg.$score_pos;

$data = $pdo->query("SELECT id,bg_name,bg_desc FROM management WHERE score_group LIKE '%$score_group%'");
$r = $data->fetch(PDO::FETCH_BOTH);
$id_manag = 99;

if ($r){
	$id_manag = $r['id'];
	$bg_name = $r['bg_name'];
	$bg_desc = $r['bg_desc'];
}else{
	$bg_name='';
	$bg_desc='';
}
$posi = percent($sum_pos, $sum_pos+$sum_neg);
$nega = percent($sum_neg, $sum_pos+$sum_neg);
//---------------------------->
echo '<tr><td><center>'.$current_id.'</center></td>';

$data = $pdo->query("SELECT emotion_id FROM emotions_stat WHERE id = $current_id");
	while($r = $data->fetch(PDO::FETCH_BOTH)) {
			
		$e_id = $r['emotion_id'];
		if($e_id!=-1) $emotion_row_array[$e_id] = 1;
		if($e_id != -1)$domain_row_array[$domain[$e_id]] = 1;
		
		{
			$emotion = $pdo->query("SELECT * FROM emotions WHERE id = $e_id")->fetch(PDO::FETCH_BOTH);
			if ($emotion['valence_id'] == 0)
				$domains_category_array ['pos'][$domain[$e_id]] = 1;
			else
				$domains_category_array ['neg'][$domain[$e_id]] = 1;
		}
	}
	$positives = array_sum($domains_category_array['pos']); 
	$negatives = array_sum($domains_category_array['neg']); 
	$count_e = array_sum($domain_row_array);
//---------------------------->
$count_p=0;	
	$data = $pdo->query("SELECT label FROM photoes_stat WHERE id = $current_id");
	while($r = $data->fetch(PDO::FETCH_BOTH)) {
		$p_id = $r['label'];
		if($p_id != "0") $count_p+=1;

	}
//---------------------------->
$max_photoes = "0000-00-00 00:00:00";
$min_photoes = "9999-99-99 99:99:99";

$data = $pdo->query("SELECT timing_label FROM photoes_stat WHERE id = $current_id");
while($r = $data->fetch(PDO::FETCH_BOTH))
{
	$time = $r['timing_label'];
	if ($time == '') continue;
	$min_photoes = min($min_photoes, $time);
	$max_photoes = max($max_photoes, $time);
}

$max_emotions = "0000-00-00 00:00:00";
$min_emotions = "9999-99-99 99:99:99";

$data = $pdo->query("SELECT timing FROM emotions_stat WHERE id = $current_id");
while($r = $data->fetch(PDO::FETCH_BOTH))
{
	$time = $r['timing'];
	if ($time == '') continue;
	$min_emotions = min($min_emotions, $time);
	$max_emotions = max($max_emotions, $time);
}

$max_emotions_pos = "0000-00-00 00:00:00";
$min_emotions_pos = "9999-99-99 99:99:99";
$max_emotions_neg = "0000-00-00 00:00:00";
$min_emotions_neg = "9999-99-99 99:99:99";
$data = $pdo->query("SELECT timing, valence_id FROM emotions t1 INNER JOIN emotions_stat t2 ON t1.id = t2.emotion_id WHERE t2.id = $current_id AND t1.valence_id = 0");
while($r = $data->fetch(PDO::FETCH_BOTH))
{
	$time = $r['timing'];
	if ($time == '') continue;
	$min_emotions_pos = min($min_emotions_pos, $time);
	$max_emotions_pos = max($max_emotions_pos, $time);
}
$data = $pdo->query("SELECT timing, valence_id FROM emotions t1 INNER JOIN emotions_stat t2 ON t1.id = t2.emotion_id WHERE t2.id = $current_id AND t1.valence_id = 1");
while($r = $data->fetch(PDO::FETCH_BOTH))
{
	$time = $r['timing'];
	if ($time == '') continue;
	$min_emotions_neg = min($min_emotions_neg, $time);
	$max_emotions_neg = max($max_emotions_neg, $time);
}

$max_states = "0000-00-00 00:00:00";
$min_states = "9999-99-99 99:99:99";

$data = $pdo->query("SELECT timing FROM states_stat WHERE id = $current_id");
while($r = $data->fetch(PDO::FETCH_BOTH))
{
	$time = $r['timing'];
	if ($time == '') continue;
	$min_states = min($min_states, $time);
	$max_states = max($max_states, $time);
}

$max_scripts = "0000-00-00 00:00:00";
$min_scripts = "9999-99-99 99:99:99";

$data = $pdo->query("SELECT time FROM miniscripts_stat WHERE id = $current_id");
while($r = $data->fetch(PDO::FETCH_BOTH))
{
	$time = $r['time'];
	if ($time == '') continue;
	$min_scripts = min($min_scripts, $time);
	$max_scripts = max($max_scripts, $time);
}
	
$max_scripts2 = "0000-00-00 00:00:00";
$min_scripts2 = "9999-99-99 99:99:99";

$data = $pdo->query("SELECT time FROM miniscripts2_stat WHERE id = $current_id");
while($r = $data->fetch(PDO::FETCH_BOTH))
{
	$time = $r['time'];
	if ($time == '') continue;
	$min_scripts2 = min($min_scripts2, $time);
	$max_scripts2 = max($max_scripts2, $time);
}

$max_gros = "0000-00-00 00:00:00";
$min_gros = "9999-99-99 99:99:99";

$data = $pdo->query("SELECT timing FROM gros_stat WHERE id = $current_id");
while($r = $data->fetch(PDO::FETCH_BOTH))
{
	$time = $r['timing'];
	if ($time == '') continue;
	$min_gros = min($min_gros, $time);
	$max_gros = max($max_gros, $time);
}
$duration_photoes = 0;
$duration_emotions = 0;
$duration_emotions_pos = 0;
$duration_emotions_neg = 0;
$duration_states = 0;
$duration_scripts = 0;
$duration_scripts2 = 0;
$duration_gros = 0;
//////////////TODO: SELECT * FROM miniscripts_stat t1 INNER JOIN miniscripts2_stat t2 ON t1.id = t2.id WHERE t1.miniscript_id=t2.miniscript_id
try {
	$datetime1 = new DateTime($min_photoes);
	$datetime2 = new DateTime($max_photoes);
	$duration_photoes = interval_to_duration($datetime1->diff($datetime2));
	
}catch (Exception $ex) {}try{
	$datetime3 = new DateTime($min_emotions);
	$datetime4 = new DateTime($max_emotions);
	$duration_emotions = interval_to_duration($datetime3->diff($datetime4));
	
}catch (Exception $ex) {}try{
	$datetime5 = new DateTime($min_emotions_pos);
	$datetime6 = new DateTime($max_emotions_pos);
	$duration_emotions_pos = interval_to_duration($datetime5->diff($datetime6));
	
}catch (Exception $ex) {}try{
	$datetime7 = new DateTime($min_emotions_neg);
	$datetime8 = new DateTime($max_emotions_neg);
	$duration_emotions_neg = interval_to_duration($datetime7->diff($datetime8));
	
}catch (Exception $ex) {}try{
	$datetime9 = new DateTime($min_states);
	$datetime10 = new DateTime($max_states);
	$duration_states = interval_to_duration($datetime9->diff($datetime10));
	
}catch (Exception $ex) {}try{
	$datetime11 = new DateTime($min_scripts);
	$datetime12 = new DateTime($max_scripts);
	$duration_scripts = interval_to_duration($datetime11->diff($datetime12));
	
}catch (Exception $ex) {}try{
	$datetime13 = new DateTime($min_scripts2);
	$datetime14 = new DateTime($max_scripts2);
	$duration_scripts2 = interval_to_duration($datetime13->diff($datetime14));
	
}catch (Exception $ex) {}try{
	$datetime15 = new DateTime($min_gros);
	$datetime16 = new DateTime($max_gros);
	$duration_gros = interval_to_duration($datetime15->diff($datetime16));
}catch (Exception $ex) {}
$duration = $duration_photoes + $duration_emotions + $duration_states + $duration_scripts + $duration_scripts2 + $duration_gros;
$duration1 = $duration_emotions + $duration_states + $duration_scripts + $duration_scripts2 + $duration_gros;

//---------------------------->

$ed_pos = 0;
$ed_neg = 0;
$ed_tot = 0;
for($J = 0; $J<DOMAINS_NUMBER; $J++)
{
	$ed_pos += ed ($domains_category_array ['pos'][$J], $positives);
	$ed_neg += ed ($domains_category_array ['neg'][$J], $negatives);
}
$ed_tot = $ed_pos + $ed_neg;

//---------------------------->
$string00_ = round (($duration_photoes), 2); 
$string00_ = str_replace(".", ",", $string00_);
echo '<td><center>'.$string00_.'</center></td>'; //Време за разпознаване на емоции (Ekman & Friesen 1975)

$string001_ = round (($duration_emotions), 2); 
$string001_ = str_replace(".", ",", $string001_);
echo '<td><center>'.$string001_.'</center></td>'; //Време за отчитане на избраните семейства (Фердинандов 2018)

$string003_ = round (($duration_emotions_neg), 2); 
$string003_ = str_replace(".", ",", $string003_);
echo '<td><center>'.$string003_.'</center></td>'; //Време за отчитане на отрицателните семейства (Фердинандов 2018)

$string004_ = round (($duration_states), 2); 
$string004_ = str_replace(".", ",", $string004_);
echo '<td><center>'.$string004_.'</center></td>'; //Време за свързване на темите (Demorest 2008)

echo '<td><center>'.$count_m.'</center></td>';//Брой свързани сценарии (Tomkins 1978)

$string005_ = round (($duration_scripts), 2); 
$string005_ = str_replace(".", ",", $string005_);
echo '<td><center>'.$string005_.'</center></td>'; //Време за свързване на сценарии (Tomkins 1978)

$string0 = to_minutes ($duration); 
$string0 = str_replace(".", ",", $string0); 
echo '<td><center>'.$string0.'</center></td>';// Общо време за участие, в минути.

$string2 = round ((($positives > 0) ? (floatval ($negatives*$negatives) / $positives) : 0), 2); 
$string2 = str_replace(".", ",", strval($string2));
echo '<td><center>'.$string2.'</center></td>';// Ниво на фрустрация (Brown & Farber 1951)

echo '<td><center>'.(($sum_pos + $sum_neg) - ($sum_pos - $sum_neg)).'</center></td>'; // Ниво на конфликтите (Kaplan 1972)

$string13 = round ((-$sum_pos + 3 * $sum_neg) / 2, 2); 
$string13 = str_replace(".", ",", $string13);
echo '<td><center>'.$string13.'</center></td>';// Потенциално противоречие 2( Thompson et al. 1995)

$string15 = round (floatval($sum_pos+$sum_neg)/2, 2); // б.2 Изразеност на противоречията(Thompson et al. 1995)
$string15 = str_replace(".", ",", $string15);
echo '<td><center>'.$string15.'</center></td>';

$string16_ = round ((5*($sum_neg/2))/100, 2); 
$string16_ = str_replace(".", ",", $string16_);
echo '<td><center>'.$string16_.'</center></td>';// Ниво на преживяна фрустрация, с градиращ праг 2 (Priester & Petty 1996)

$string17_ = round (($negatives > 0) ? (5 * ($sum_neg * (0.5 * $sum_neg)) - ($sum_pos * $sum_pos * 1.0 / $sum_neg)) / 10 : 0, 2); 
$string17_ = str_replace(".", ",", $string17_);
echo '<td><center>'.$string17_.'</center></td>'; // Ниво на преживяна фрустрация, с рязък праг (Priester & Petty 1996)

$string24 = round (($negatives > $positives) ?(($sum_neg*$negatives/($negatives - $positives))/100) :0 ,3);
//$string24 = round (($negatives > $positives) ?(($sum_neg*($negatives + $positives)/($negatives - $positives))/100) :0 ,3);
//$string24 = round (($negatives > $positives) ?(($duration_emotions_neg*$sum_neg)/100) :0 ,3);
//$string24 = round (($sum_neg > $sum_pos) ?(($duration_emotions_neg*$sum_neg)/100) :0 ,3);
$string24 = str_replace(".", ",", $string24);
echo '<td><center>'.$string24.'</center></td>';// б. Experienced misery (Juster et al. 1985, Kahneman et al. 2006)

$string25 = round (($negatives > $positives) ?(($sum_neg*$negatives/($negatives - $positives))/10) :0 ,3);
$string25 = str_replace(".", ",", $string25);
echo '<td><center>'.$string25.'</center></td>';// б. Misery index (Ferdinandov 2019)

//---------------------------------------->
echo '</tr>';
}
echo '</table>';
require "end.php";
?>