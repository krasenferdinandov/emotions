<?php
require "headerbg.php";
//---------------->
$string = array();
$domain = array();
$emotions = array();
$sum_pos=0;$count_pos=0;
$sum_neg=0;$count_neg=0;
$sum_ambi=0;$count_ambi=0;
$sel_emotions = array();

//ЗА РЕДАКЦИЯ
//---------------------------->
function interval_to_duration ($interval) {
	return ($interval->h*60 + $interval->i + (floatval($interval->s) / 60));
}
function to_minutes ($duration) {
	return floor($duration) + ($duration - floor($duration)) * 60 / 100;
}
function ed ($category, $total)
{
	if($category>0 && $total > 0)
		return -1*($category/$total)*log($category/$total);
	else
		return 0;
}
function isInDomain($emotion_search){
	return (floor($emotion_search));
}


//---------------------------->
if(!array_key_exists('id', $_GET)){
	die();
}
$id = $_GET['id'];
validateInt($id);
echo '<form id="the_form" method="POST" action="testsbg.php" enctype="multipart/form-data" onSubmit="return checkboxesOkay(this);">';

$statement = $pdo->query("SELECT id, string_id FROM emotions");
while($row = $statement->fetch(PDO::FETCH_BOTH))
{
	$string[$row['id']] = $row['string_id'];
}

$statement1 = $pdo->query("SELECT * FROM domains s, emotions sc WHERE sc.domain_id = s.id ");
while($row = $statement1->fetch(PDO::FETCH_BOTH))
{
	$domain[$row['id']] = $row['domain_id'];
}

$data = $pdo->query("SELECT emotion_id FROM emotions_stat WHERE id = $id");
	while($r = $data->fetch(PDO::FETCH_BOTH)) {
			
		$e_id = $r['emotion_id'];
		if($e_id!=-1) $emotion_row_array[$e_id] = 1;
		if($e_id != -1)$domain_row_array[$domain[$e_id]] = 1;
		
		{
			$emotion = $pdo->query("SELECT * FROM emotions WHERE id = $e_id")->fetch(PDO::FETCH_BOTH);
			if ($emotion['valence_id'] == 0)
				$domains_category_array ['pos'][$domain[$e_id]] = 1;
			else
				$domains_category_array ['neg'][$domain[$e_id]] = 1;
		}
	}
	$positives = array_sum($domains_category_array['pos']); 
	$negatives = array_sum($domains_category_array['neg']); 
	$count_e = array_sum($domain_row_array);

$data = $pdo->query("SELECT timing FROM emotions_stat WHERE id = $id");
while($r = $data->fetch(PDO::FETCH_BOTH))
{
	$time = $r['timing'];
	if ($time == '') continue;
	$min_emotions = min($min_emotions, $time);
	$max_emotions = max($max_emotions, $time);
}
echo '<input type="hidden" name="id" value="'.$id.'">';

//Показва съобщение за резултата с текущото ID
echo'<center><b>'.ID.'<br></b>'.TIP2.'<b>'.$id.'</b><center/>';
echo '</br><input type="submit" value="Други тестове"/><br/>';

$table_result = '<table class="borders"><tr><th colspan="2"><center>РЕЗУЛТАТИ<center/></th><center/><br/></tr>';

$recognition=0;
$photoes = $pdo->query("Select SUM(label) FROM photoes_stat WHERE id=$id");
$r = $photoes->fetch(PDO::FETCH_BOTH);
$recognition= $r['SUM(label)'];
echo '<p><b>2. Успешно разпознати емоции (Ekman & Friesen, 1975): </b>'.$count_p.' от 5 лицеви изражения</p>';


$posi = '';
$nega = '';
$sum_pos=0;$count_pos=0;
$sum_neg=0;$count_neg=0;
$sel_emotions = $pdo->query("SELECT * FROM emotions_stat WHERE id=$id");
while($r = $sel_emotions->fetch(PDO::FETCH_BOTH)){
	$e_id=$r['emotion_id'];
	$e_sl=$r['e_slider'];
	
	$data = $pdo->query("SELECT domain_id, valence_id, string_id, tension_id FROM emotions WHERE id = $e_id LIMIT 1");
	$r = $data->fetch(PDO::FETCH_BOTH);
	$domain_id = intval($r['domain_id']);
	$dimension_id = $r['valence_id'];
	$e_string = $r['string_id'];
	$e_tension = $r['tension_id'];
	
		if ($e_string == 0){			
		$density= (($e_sl*0.4)+$e_tension);
		}
		else if($e_string == 1){
		$density=(($e_sl*0.6)+$e_tension);
		}
		else if($e_string == 2){
		$density=(($e_sl*0.8)+$e_tension);
		}
		
		if($dimension_id == 0){
			$sum_pos+=$e_sl;
			//$sum_pos+=$density;
			$count_pos+=1;
		}
		if($dimension_id == 1){
			$sum_neg+=$e_sl;
			//$sum_neg+=$density;
			$count_neg+=1;
		}
}		
$score_neg=scores_level($sum_neg, $count_neg);
$score_pos=scores_level($sum_pos, $count_pos);
$score_group=$score_neg.$score_pos;
$posi = percent($sum_pos, $sum_pos+$sum_neg);
$nega = percent($sum_neg, $sum_pos+$sum_neg);

	
	$e_id=$r['emotion_id'];
	$e_sl=$r['e_slider'];
	
	$data = $pdo->query("SELECT manag FROM id_stat WHERE id = $id LIMIT 1");
	$r = $data->fetch(PDO::FETCH_BOTH);
	$manag = $r['manag'];
	
	$data = $pdo->query("SELECT domain_id, dimension_id, valence_id, en_name, bg_name, string_id, tension_id FROM emotions WHERE id = $e_id LIMIT 1");
	$r = $data->fetch(PDO::FETCH_BOTH);
	$domain_id = intval($r['domain_id']);
	$en_name = $r['en_name'];
	$bg_name = $r['bg_name'];
	$dimension_id = $r['valence_id'];
	$e_string = $r['string_id'];
	$e_tension = $r['tension_id'];
	
	$density=$e_sl;
	
//Показва "плътността" на избраните емоции.
	$table_result .= '<tr><td style="border: 1px solid #c0c0c0;"><a title="'.quot($script_name).', '.quot($script_desc).'"><b>* '.quot($bg_name).'</b></a></td>';
	$table_result .= '<td style="border: 1px solid #c0c0c0;">'.DENSITY.''.$density.'</td></tr>';
//---------------------------------->
//КРАЙ НА ИНДИВИДУАЛНИЯ ПРОФИЛ

//ЗА РЕДАКЦИЯ 
//---------------------------------->
$max_emotions_pos = "0000-00-00 00:00:00";
$min_emotions_pos = "9999-99-99 99:99:99";
$max_emotions_neg = "0000-00-00 00:00:00";
$min_emotions_neg = "9999-99-99 99:99:99";
$data = $pdo->query("SELECT timing, valence_id FROM emotions t1 INNER JOIN emotions_stat t2 ON t1.id = t2.emotion_id WHERE t2.id = $id AND t1.valence_id = 0");
while($r = $data->fetch(PDO::FETCH_BOTH))
{
	$time = $r['timing'];
	if ($time == '') continue;
	$min_emotions_pos = min($min_emotions_pos, $time);
	$max_emotions_pos = max($max_emotions_pos, $time);
}
$data = $pdo->query("SELECT timing, valence_id FROM emotions t1 INNER JOIN emotions_stat t2 ON t1.id = t2.emotion_id WHERE t2.id = $id AND t1.valence_id = 1");
while($r = $data->fetch(PDO::FETCH_BOTH))
{
	$time = $r['timing'];
	if ($time == '') continue;
	$min_emotions_neg = min($min_emotions_neg, $time);
	$max_emotions_neg = max($max_emotions_neg, $time);
}

$max_states = "0000-00-00 00:00:00";
$min_states = "9999-99-99 99:99:99";
$duration_emotions = 0;
$duration_emotions_pos = 0;
$duration_emotions_neg = 0;
try{
	$datetime3 = new DateTime($min_emotions);
	$datetime4 = new DateTime($max_emotions);
	$duration_emotions = interval_to_duration($datetime3->diff($datetime4));
	
}catch (Exception $ex) {}try{
	$datetime5 = new DateTime($min_emotions_pos);
	$datetime6 = new DateTime($max_emotions_pos);
	$duration_emotions_pos = interval_to_duration($datetime5->diff($datetime6));
	
}catch (Exception $ex) {}try{
	$datetime7 = new DateTime($min_emotions_neg);
	$datetime8 = new DateTime($max_emotions_neg);
	$duration_emotions_neg = interval_to_duration($datetime7->diff($datetime8));
	
}catch (Exception $ex) {}
	$count_e=0;	
	$sel_emotions = $pdo->query("Select * FROM emotions_stat WHERE id=$id");
	while($r = $sel_emotions->fetch(PDO::FETCH_BOTH)){
		$count_e+=1;
		}


echo '<td><center>'.$count_p.'</center></td>'; //Разпознаване на емоции (Ekman & Friesen 1975)
$string00_ = round (($duration_photoes), 2); 
$string00_ = str_replace(".", ",", $string00_);
echo '<td><center>'.$string00_.'</center></td>'; //Време за разпознаване на емоции (Ekman & Friesen 1975)
//echo '<td><center>'.$duration_photoes.'</center></td>'; //Време за разпознаване на емоции (Ekman & Friesen 1975)

echo '<td><center>'.$count_e.'</center></td>'; //Общ брой избрани семейства (Фердинандов 2018)

$string001_ = round (($duration_emotions), 2); 
$string001_ = str_replace(".", ",", $string001_);
echo '<td><center>'.$string001_.'</center></td>'; //Време за отчитане на избраните семейства (Фердинандов 2018)

echo '<td><center>'.$positives.'</center></td>';//Брой положителни семейства (Фердинандов 2018)
$string002_ = round (($duration_emotions_pos), 2); 
$string002_ = str_replace(".", ",", $string002_);
echo '<td><center>'.$string002_.'</center></td>'; //Време за отчитане на избрани емоции (Фердинандов 2018)

echo '<td><center>'.$negatives.'</center></td>';//Брой отрицателни семейства (Фердинандов 2018)
$string003_ = round (($duration_emotions_neg), 2); 
$string003_ = str_replace(".", ",", $string003_);
echo '<td><center>'.$string003_.'</center></td>'; //Време за отчитане на избрани емоции (Фердинандов 2018)

$string01_ = round (($sum_pos+$sum_neg/$count_e)/10, 1); 
$string01_ = str_replace(".", ",", $string01_);
echo '<td><center>'.$string01_.'</center></td>'; // Обща средна продължителност на избраните семейства (Фердинандов 2018)

$string02_ = round (($positives > 0) ? ($sum_pos/$positives) : 0, 1); 
$string02_ = str_replace(".", ",", $string02_);
echo '<td><center>'.$string02_.'</center></td>'; // Обща средна продължителност на избраните положителни семейства (Фердинандов 2018)

$string03_ = round (($negatives > 0 ) ? ($sum_neg/$negatives) : 0, 1); 
$string03_= str_replace(".", ",", $string03_);
echo '<td><center>'.$string03_.'</center></td>'; // Обща средна продължителност на избраните положителни семейства (Фердинандов 2018)

echo '<td><center>'.$count_s.'</center></td>';//Брой свързани теми (Demorest 2008)
$string004_ = round (($duration_states), 2); 
$string004_ = str_replace(".", ",", $string004_);
echo '<td><center>'.$string004_.'</center></td>'; //Време за отчитане на избрани емоции (Фердинандов 2018)

echo '<td><center>'.$count_m.'</center></td>';//Брой припознати сценарии (Tomkins 1978)
$string005_ = round (($duration_scripts), 2); 
$string005_ = str_replace(".", ",", $string005_);
echo '<td><center>'.$string005_.'</center></td>'; //Време за отчитане на избрани емоции (Фердинандов 2018)

$string01 = $sum_sup;
//$string01 = $count_sup;
$string01 = str_replace(".", ",", $string01); 
echo '<td><center>'.$string01.'</center></td>';//Регулация чрез потискане (Gross & John 2003)

$string02 = $sum_reap;
//$string02 = $count_reap;
$string02 = str_replace(".", ",", $string02); 
echo '<td><center>'.$string02.'</center></td>';//Регулация чрез преоценка (Gross & John 2003)

$string007 = ($count_reap + $count_sup);
//$string02 = $count_reap;
$string007 = str_replace(".", ",", $string007); 
echo '<td><center>'.$string007.'</center></td>';//Брой идентифицирани твърдения за регулация (Gross & John 2003)

$string006_ = round (($duration_gros), 2); 
$string006_ = str_replace(".", ",", $string006_);
echo '<td><center>'.$string006_.'</center></td>'; //Време за отчитане на избрани емоции (Фердинандов 2018)

//---------------------------------------------------->

$string0 = to_minutes ($duration); 
$string0 = str_replace(".", ",", $string0); 
echo '<td><center>'.$string0.'</center></td>';// Време за участие, в минути.

$string1 = round ((1-exp(-1*to_minutes ($duration1)))/($count_p+$count_e), 3);
$string1 = str_replace(".", ",", $string1);
echo '<td><center>'.$string1.'</center></td>';// Достъпност на идентификациите (Bousfield & Sedgwick 1944)

$string2 = round ((($positives > 0) ? (floatval ($negatives*$negatives) / $positives) : 0), 1); 
$string2 = str_replace(".", ",", strval($string2));
echo '<td><center>'.$string2.'</center></td>';// Ниво на фрустрация (Brown & Farber 1951)

$string2_ = round ((($positives > 0) ? (floatval ($sum_neg*$sum_neg) / $sum_pos) : 0), 2); 
$string2_ = str_replace(".", ",", strval($string2_));
echo '<td><center>'.$string2_.'</center></td>';// Ниво на фрустрация (Brown & Farber 1951)

$string3 = round ((($count_e * log (1/$count_e, 2))/log (10, 2)), 2); 
$string3 = str_replace(".", ",", $string3);
echo '<td><center>'.$string3.'</center></td>';// Разграничаване на емоции (Scott 1966)

$string007_ = round ((log (10, 2) - (($count_e *log ($count_e, 2))/10)), 2);
$string007_ = str_replace(".", ",", $string007_);
echo '<td><center>'.$string007_.'</center></td>';// Сложност на афективните идентификации  (Scott 1966)

$string4_ = round ((2*$positives + 1) / ($positives + $negatives + 2), 2);
$string4_ = str_replace(".", ",", $string4_);
echo '<td><center>'.$string4_.'</center></td>';// Обективно двусмислие (Scott 1966)

$string4 = round ((2*$sum_pos + 1) / ($sum_pos + $sum_neg + 2), 2); 
$string4 = str_replace(".", ",", $string4);
echo '<td><center>'.$string4.'</center></td>';// Обективно двусмислие (Scott 1966)

$string25 = round ((($positives-$negatives)), 2); 
$string25 = str_replace(".", ",", $string25);
echo '<td><center>'.$string25.'</center></td>';// Афективен баланс (Bradburn 1969)

$string26_ = round ((($sum_pos-$sum_neg)), 2); 
$string26_ = str_replace(".", ",", $string26_);
echo '<td><center>'.$string26_.'</center></td>';// Афективен баланс (Bradburn 1969)

echo '<td><center>'.(($positives + $negatives) - abs($positives - $negatives)).'</center></td>'; // Ниво на конфликтите (Kaplan 1972)

echo '<td><center>'.(($sum_pos + $sum_neg) - abs($sum_pos - $sum_neg)).'</center></td>'; // Ниво на конфликтите (Kaplan 1972)

$string9 = round (($positives * $negatives), 2); 
$string9 = str_replace(".", ",", $string9);
echo '<td><center>'.$string9.'</center></td>';// Контрасти в амбивалентността (Katz 1986)

$string10 = round ((floatval($positives+$negatives)/2 -abs($positives-$negatives)), 2); 
$string10 = str_replace(".", ",", $string10);
echo '<td><center>'.$string10.'</center></td>';// Потенциално противоречие 1( Thompson et al. 1995)

$string11 = round (-abs($positives-$negatives), 2); 
$string11 = str_replace(".", ",", $string11);
echo '<td><center>'.$string11.'</center></td>';// а.1 Подобие между противоположни състояния (Thompson et al. 1995)

$string12 = round (floatval($positives+$negatives)/2, 2); 
$string12 = str_replace(".", ",", $string12);
echo '<td><center>'.$string12.'</center></td>';// б.1 Изразеност на противоречията(Thompson et al. 1995)

$string13 = round (((floatval($sum_pos+$sum_neg)/2) - abs($sum_pos-$sum_neg)), 2); 
$string13 = str_replace(".", ",", $string13);
echo '<td><center>'.$string13.'</center></td>';// Потенциално противоречие 2( Thompson et al. 1995)

$string14 = round (-abs($sum_pos-$sum_neg), 2); 
$string14 = str_replace(".", ",", $string14);
echo '<td><center>'.$string14.'</center></td>';// а.2 Подобие между противоположни състояния (Thompson et al. 1995)

$string15 = round (floatval($sum_pos+$sum_neg)/2, 2); 
$string15 = str_replace(".", ",", $string15);
echo '<td><center>'.$string15.'</center></td>';// б.2 Изразеност на противоречията(Thompson et al. 1995)

$string16 = round ((5*($negatives/2))/10, 2); 
$string16 = str_replace(".", ",", $string16);
echo '<td><center>'.$string16.'</center></td>';// Ниво на преживяна фрустрация, с градиращ праг (Priester & Petty 1996)

$string16_ = round ((5*($sum_neg/2))/100, 2); 
$string16_ = str_replace(".", ",", $string16_);
echo '<td><center>'.$string16_.'</center></td>';// Ниво на преживяна фрустрация, с градиращ праг (Priester & Petty 1996)

$string17 = round (($negatives > 0) ? (5 * ($negatives * (0.5 * $negatives)) - ($positives * $positives * 1.0 / $negatives)) / 10 : 0, 2); 
$string17 = str_replace(".", ",", $string17);
echo '<td><center>'.$string17.'</center></td>'; // Ниво на преживяна фрустрация, с рязък праг (Priester & Petty 1996)

$string17_ = round (($negatives > 0) ? (5 * ($sum_neg * (0.5 * $sum_neg)) - ($sum_pos * $sum_pos * 1.0 / $sum_neg)) / 10 : 0, 2); 
$string17_ = str_replace(".", ",", $string17_);
echo '<td><center>'.$string17_.'</center></td>'; // Ниво на преживяна фрустрация, с рязък праг (Priester & Petty 1996)

$string18 = round ((abs($positives-$negatives)), 2); 
$string18 = str_replace(".", ",", $string18);
echo '<td><center>'.$string18.'</center></td>';// Амбивалентна реакция (Choi & Choi 2002)

$string18_ = round ((abs($sum_pos-$sum_neg)), 2); 
$string18_ = str_replace(".", ",", $string18_);
echo '<td><center>'.$string18_.'</center></td>';// Амбивалентна реакция (Choi & Choi 2002)

$string19 = round (($positives / ($negatives+$positives)), 2); 
$string19 = str_replace(".", ",", $string19);
echo '<td><center>'.$string19.'</center></td>';// Пропорционалност в преценките (Schwartz 2002)

$string19_= round (($sum_pos / ($sum_neg+$sum_pos)), 2);
$string19_ = str_replace(".", ",", $string19_);
echo '<td><center>'.$string19_.'</center></td>';// Пропорционалност в преценките (Schwartz 2002)

$string24 = round (($negatives > $positives) ?(($sum_neg*$negatives)) :0 ,3);
$string24 = str_replace(".", ",", $string24);
echo '<td><center>'.$string24.'</center></td>';// б. Experienced misery (Juster et al. 1985, Kahneman et al. 2006)

$string20 = round (($negatives > 0) ? ($positives / ($negatives)) : 0, 2); 
$string20 = str_replace(".", ",", $string20);
echo '<td><center>'.$string20.'</center></td>';// Емоционално благополучие, без pi (Larsen 2009)

$string20_ = round (($sum_neg > 0) ? ($sum_pos / ($sum_neg)) : 0, 2); 
$string20_ = str_replace(".", ",", $string20_);
echo '<td><center>'.$string20_.'</center></td>';// Емоционално благополучие, без pi (Larsen 2009)

$string27 = min(array(max(array($positives))+max(array($negatives)))); 
$string27 = str_replace(".", ",", $string27);
echo '<td><center>'.$string27.'</center></td>';// Смесени чувства (Kruger 2009)

$string29 = min(array($positives/5 + $negatives/5)); 
$string29 = str_replace(".", ",", $string29);
echo '<td><center>'.$string29.'</center></td>';// Смесени чувства (Larsen & Hershfield 2012)

$string30 = round (($negatives > 0) ? min(array($positives / ($negatives))) : 0, 2); 
$string30 = str_replace(".", ",", $string30);
echo '<td><center>'.$string30.'</center></td>';// Смесени емоции (Podoynitsyna et al.  2012)

$string21 = round (($ed_tot), 2); 
$string21 = str_replace(".", ",", $string21);
echo '<td><center>'.$string21.'</center></td>';// Общо емоционално разнообразие (Quoidbach et al. 2014)

$string22 = round (($ed_pos), 2); 
$string22 = str_replace(".", ",", $string22);
echo '<td><center>'.$string22.'</center></td>';// а. Разнообразие в положителните състояния (Quoidbach et al. 2014)

$string23 = round (($ed_neg), 2); 
$string23 = str_replace(".", ",", $string23);
echo '<td><center>'.$string23.'</center></td>';// б. Разнообразие в отрицателните състояния (Quoidbach et al. 2014)
//---------------------------------->

$table_result.='</td><tr/>';
$table_result .= '<center/></table>';
echo $table_result;
echo '</br>'.CONTRIBUTION.'</br>';
require ("js/showText.js");
require "end.php";
?>