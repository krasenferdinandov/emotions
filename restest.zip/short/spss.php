<?php
require "headerbg1.php";
echo '<table class="borders">';
echo '<tr><th>Id</th>';

function isInDomain($emotion_search){
	if($emotion_search >= 0 && $emotion_search <= 8)return 0;
	if($emotion_search >= 9 && $emotion_search <= 17)return 1;
	if($emotion_search >= 18 && $emotion_search <= 26)return 2;
	if($emotion_search >= 27 && $emotion_search <= 35)return 3;
	if($emotion_search >= 36 && $emotion_search <= 44)return 4;
	if($emotion_search >= 45 && $emotion_search <= 53)return 5;
	if($emotion_search >= 54 && $emotion_search <= 62)return 6;
	if($emotion_search >= 63 && $emotion_search <= 71)return 7;
	if($emotion_search >= 72 && $emotion_search <= 80)return 8;
	if($emotion_search >= 81 && $emotion_search <= 89)return 9;
}
$domain = array();
$emotions = array();

$label = $pdo->query("SELECT id, en_name, bg_name FROM feelings");
while($row = $label->fetch(PDO::FETCH_BOTH))
{
	$bg_name = $row['en_name'];
	$emotions[$row['id']] ='<a title="'.quot($row['bg_name']).'">'. $bg_name.'</a>';
}

$statement1 = $pdo->query("SELECT * FROM domains s, feelings sc WHERE sc.domain_id = s.id ");
while($row = $statement1->fetch(PDO::FETCH_BOTH))
{
	$domain[$row['id']] = $row['domain_id'];
	
}
for($i=0;$i<DOMAINS_NUMBER;$i++){
	$domain_data = $pdo->query("select en_name, bg_name from domains where id = ". $i . "");
	
	$name = "WRONG";
	while($r = $domain_data->fetch(PDO::FETCH_BOTH))
	{
		$en_name = $r["en_name"];
		$bg_name = $r["bg_name"];
	}
	//echo '<td><center>F'.$i.'_'.$en_name.'_'.$bg_name.'</center></td>';
	echo '<td><center>FML_'.$i.'</center></td>';
}
//------------------>
for($i=0;$i<THEMES_NUMBER;$i++){
	$script_data = $pdo->query("select en_name, bg_name from statements where id = ". $i . "");
		
	$name = "WTF";
	while($r = $script_data->fetch(PDO::FETCH_BOTH))
	{
		$en_name = $r["en_name"];
		$bg_name = $r["bg_name"];
	}
    //echo '<td><center>T'.$i.'_'.$en_name.'</center></td>';
    echo '<td><center>T'.$i.'_'.$en_name.'_'.$bg_name.'</center></td>';
	//echo '<td><center>T'.$i.'</center></td>';
}
//------------------>
for($i=0;$i<STATES_NUMBER_1;$i++){
	$niesen_data = $pdo->query("select en_name, bg_name, axis_id from niesen where id = ". $i . "");
		
	$namen = "WTF";
	while($r = $niesen_data->fetch(PDO::FETCH_BOTH))
	{
		$en_namen = $r["en_name"];
		$bg_namen = $r["bg_name"];
		$axisn = $r["axis_id"];
	}

	echo '<td><center>SDR'.$axisn.'_'.$i.'</center></td>';
}
//------------------>
//------------------>
echo '<td><center><b>Баланс</b><center></td>';
echo '<td><center><b>Нещастие</b><center></td>';
echo '<td><center><b>Себеизтъкване</b></center></td>';
echo '<td><center><b>Прикриване</b></center></td>';
echo '<td><center><b>Времетраене</b></center></td>';
echo '<td><center><b>Пол</b></center></td>';
echo '<td><center><b>Възраст</b></center></td>';
echo '<td><center><b>Статус</b></center></td>';
//------------------>
echo '</tr>';

//..................> Печати всички
$count_data = $pdo->query("SELECT id FROM duration_stat ORDER BY id");

$count = 0;
$last = -1;
$id_array = array();
while($r = $count_data->fetch(PDO::FETCH_BOTH))
{
	if($r['id'] != $last)
	{
		$last = $r['id'];
		$id_array[] = $last;
		$count++;
	}
}

for($k = 0; $k<$count; $k++)
{ 
	$current_id = $id_array[$k];
	$emotion_row_array = array();
	$domain_row_array = array();
	$domains_category_array = array();
	$states_row_array1 = array();
	$themes_row_array = array();


$data = $pdo->query("SELECT * FROM duration_stat WHERE id = $current_id LIMIT 1");
$r = $data->fetch(PDO::FETCH_BOTH);
$id = $r['id'];
if(!isset($id)) continue;
	for($i = 0; $i<EMOTIONS_NUMBER; $i++)
	{
		$emotion_row_array[] = 0;
	}
	for($i = 0; $i<DOMAINS_NUMBER; $i++)
	{
		$domain_row_array[] = 0;
		$domains_category_array ['pos'][] = 0;
		$domains_category_array ['neg'][] = 0;
	}
	$count_em=0;	
	$data = $pdo->query("SELECT emotion_id FROM duration_stat WHERE id = $current_id");
	while($r = $data->fetch(PDO::FETCH_BOTH)) {
			
		$e_id = $r['emotion_id'];
		if($e_id!=-1) $emotion_row_array[$e_id] = 1;
		if($e_id != -1)$domain_row_array[$domain[$e_id]] = 1;
		$count_em+=1;
	}
	for($i = 0; $i<THEMES_NUMBER; $i++)
	{
		$themes_row_array[] = 0;
	}
	for($i = 0; $i<STATES_NUMBER_1; $i++)
	{
		$states_row_array1[] = 0;
	}
//---------------------------->
	$sum_pos=0;
	$sum_neg=0;
	$count_pos=0;
	$count_neg=0;
	$sel_emotions = $pdo->query("SELECT * FROM duration_stat WHERE id=$current_id");
	while($r = $sel_emotions->fetch(PDO::FETCH_BOTH)){
		$e_id=$r['emotion_id'];
		$e_sl=$r['e_slider'];
		
		$data = $pdo->query("SELECT domain_id, valence_id FROM feelings WHERE id = $e_id LIMIT 1");
		$r = $data->fetch(PDO::FETCH_BOTH);
		$domain_id = intval($r['domain_id']);
		$dimension_id = $r['valence_id'];

		
			if($dimension_id == 0){
				$sum_pos+=$e_sl;
				$count_pos+=1;
			}
			if($dimension_id == 1){
				$sum_neg+=$e_sl;
				$count_neg+=1;
			}
	}
	$count_t=0;	
	$data_t = $pdo->query("SELECT * FROM states_stat WHERE id = $current_id");
	while($r = $data_t->fetch(PDO::FETCH_BOTH)) {
		$ti_id = $r['state_id'];
				
		if($ti_id!=-1) $themes_row_array[$ti_id] = 1;
		$count_t+=1;
	}
//---------------------------->	
	$data_n = $pdo->query("SELECT * FROM niesen_stat WHERE id = $current_id");
	while($r = $data_n->fetch(PDO::FETCH_BOTH)) {
		$sn_id = $r['state_id'];
		if($sn_id!=-1) $states_row_array1[$sn_id] = 1;			
	}
//---------------------------->	
	echo '<tr><td><center>'.$current_id.'</center></td>';
	for($i=0;$i<DOMAINS_NUMBER;$i++)
		if($domain_row_array[$i] != 1) {
			echo '<td><center>0</center></td>';
			//else echo '<td><center><b>1<b/></center></td>';
			//Показва вместо "1/0" предимството и плътността за даденото емоционално семейство.
		}
		else {
			$mas = "";
			$sel_emotions = $pdo->query("SELECT * FROM duration_stat e join feelings em on em.id = e.emotion_id WHERE e.id = " . $current_id . "");
			$e_sl = array ();
			while($r1 = $sel_emotions->fetch(PDO::FETCH_BOTH)) {
					$mas = $r1['emotion_id'];
					if(isInDomain($mas) != $i) continue;
					$e_sl = $r1['e_slider'];
			}
			echo '<td><center>'.$e_sl.'</center></td>';
		}
	for($i=0;$i<THEMES_NUMBER;$i++)
		if($themes_row_array[$i] != 1)
			echo '<td><center>0</center></td>';
		else {
			$data_t = $pdo->query("SELECT * FROM states_stat WHERE id = " . $current_id . "");
			while($rs = $data_t->fetch(PDO::FETCH_BOTH)) {
			$s_id = $rs['state_id'];
			if($s_id!=$i)continue;
			$s_sl = $rs['s_slider'];
			}
			echo '<td><center>'.$s_sl.'</center></td>';
		}
		//else echo '<td><center><b>1<b/></center></td>';
		
	for($i=0;$i<STATES_NUMBER_1;$i++)
		if($states_row_array1[$i] != 1){
			echo '<td><center>0</center></td>';
			}
		else {
			$data_n = $pdo->query("SELECT * FROM niesen_stat WHERE id = " . $current_id . "");
			$ni_sl = array ();
			while($rni = $data_n->fetch(PDO::FETCH_BOTH)) {
			$ni_id = $rni['state_id'];
			if($ni_id!=$i)continue;
			$ni_sl = $rni['s_slider'];
			}
			echo '<td><center>'.$ni_sl.'</center></td>';
			}
		//else echo '<td><center><b>1<b/></center></td>';
$sum_pqm=0;
$sum_nqm=0;
$niesen = $pdo->query("SELECT * FROM niesen_stat WHERE id=$current_id");
while($r = $niesen->fetch(PDO::FETCH_BOTH)){
	$n_id=$r['state_id'];
	$n_sl=$r['s_slider'];
	
	$datan = $pdo->query("SELECT axis_id FROM niesen WHERE id = $n_id LIMIT 1");
	$rn = $datan->fetch(PDO::FETCH_BOTH);
	$axisn_id = $rn['axis_id'];
			
		if($axisn_id == 0){
			$sum_pqm+= round (($n_sl/3),1);
		}
		if($axisn_id == 1){
			$sum_nqm+=round (($n_sl/3),1);
		}
}
//---------------------------->
$max_emotions = "0000-00-00 00:00:00";
$min_emotions = "9999-99-99 99:99:99";
$data = $pdo->query("SELECT timing FROM duration_stat WHERE id = $id");
while($r = $data->fetch(PDO::FETCH_BOTH))
{
	$time = $r['timing'];
	if ($time == '') continue;
	$min_emotions = min($min_emotions, $time);
	$max_emotions = max($max_emotions, $time);
}
try {
	$datetime1 = new DateTime($min_emotions);
	$datetime2 = new DateTime($max_emotions);
	
} 
catch (Exception $ex) {}

$max_themes = "0000-00-00 00:00:00";
$min_themes = "9999-99-99 99:99:99";
$data = $pdo->query("SELECT timing FROM states_stat WHERE id = $id");
while($r = $data->fetch(PDO::FETCH_BOTH))
{
	$time = $r['timing'];
	if ($time == '') continue;
	$min_themes = min($min_themes, $time);
	$max_themes = max($max_themes, $time);
}
try {
	$datetime5 = new DateTime($min_themes);
	$datetime6 = new DateTime($max_themes);
	
} 
catch (Exception $ex) {}

$max_niesen = "0000-00-00 00:00:00";
$min_niesen = "9999-99-99 99:99:99";

$data = $pdo->query("SELECT timing FROM niesen_stat WHERE id = $id");
while($r = $data->fetch(PDO::FETCH_BOTH))
{
	$time = $r['timing'];
	if ($time == '') continue;
	$min_niesen = min($min_niesen, $time);
	$max_niesen = max($max_niesen, $time);
}

try{
	$datetime7 = new DateTime($min_niesen);
	$datetime8 = new DateTime($max_niesen);
	
}
catch (Exception $ex) {}

$start = "0000-00-00 00:00:00";
$data = $pdo->query("SELECT start FROM duration_timing WHERE id = $id");
while($r = $data->fetch(PDO::FETCH_BOTH))
{
	$start = $r['start'];
	$datetime3 = new DateTime($start);
}
$end = "0000-00-00 00:00:00";
$data = $pdo->query("SELECT end FROM duration_timing WHERE id = $id");
while($r = $data->fetch(PDO::FETCH_BOTH))
{
	$end = $r['end'];
	$datetime4 = new DateTime($end);
	
}
$data = $pdo->query("SELECT choice FROM gender_stat WHERE id = $id");
while($r = $data->fetch(PDO::FETCH_BOTH))
{
	$gender = $r['choice'];
}
$data = $pdo->query("SELECT choice FROM age_stat WHERE id = $id");
while($r = $data->fetch(PDO::FETCH_BOTH))
{
	$age = $r['choice'];
}
$data = $pdo->query("SELECT choice FROM health_stat WHERE id = $id");
while($r = $data->fetch(PDO::FETCH_BOTH))
{
	$health = $r['choice'];
}
$emotions_selection = interval_to_duration($datetime1->diff($datetime2));
$slider_assessment = interval_to_duration($datetime3->diff($datetime4));
$themes_selection = interval_to_duration($datetime5->diff($datetime6));
$duration_niesen = interval_to_duration($datetime7->diff($datetime8));
$latency = $emotions_selection + $slider_assessment + $themes_selection + $duration_niesen;
//---------------------------------------------------->
//---------------------------->
//$string01 = round ((($sum_pos-$sum_neg)), 2);
$string01 = round ((($count_pos-$count_neg)), 2); 
$string01 = str_replace(".", ",", $string01);
echo '<td><center>'.$string01.'</center></td>';// Афективен баланс (Bradburn 1969)
	
$string02 = round (($count_neg > $count_pos) ?(($sum_neg*$count_neg)) :0 ,3);
$string02 = str_replace(".", ",", $string02);
echo '<td><center>'.$string02.'</center></td>';// Индекс на нещастието (Kahneman & Kruger 2006)

$string05 = $sum_pqm;
$string05 = str_replace(".", ",", $string05); 
echo '<td><center>'.$string05.'</center></td>';

$string06 = $sum_nqm;
$string06 = str_replace(".", ",", $string06); 
echo '<td><center>'.$string06.'</center></td>';

$string00 = round (to_minutes ($latency) ,2); 
$string00 = str_replace(".", ",", $string00); 
echo '<td><center>'.$string00.'</center></td>';
//---------------------------->
echo '<td><center>'.$gender.'</center></td>';
echo '<td><center>'.$age.'</center></td>';
echo '<td><center>'.$health.'</center></td>';
//---------------------------->	
	
	echo '</tr>';
}

echo '</table>';
require "end1.php";
?>