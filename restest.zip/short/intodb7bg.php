<?php
date_default_timezone_set("Europe/Sofia");
require_once "constantsbg1.php";
require_once "db_pass1.php";
if (array_key_exists('id', $_POST))
	{
	echo '<input type="hidden" name="id" value="'.$_POST['id'].'">';
	$id = $_POST['id'];
	}
else if (array_key_exists('id', $_GET))
	{
	echo '<input type="hidden" name="id" value="'.$_GET['id'].'">';
	$id = $_GET['id'];
	}
echo '<input type="hidden" name="id" value="'.$id.'">';

echo '<input type="hidden" name="id" value="'.$id.'">';
	if($_POST['choice']== '1') {
		$pdo->exec("INSERT INTO health_stat VALUES ($id,'1', NOW());");	
		}
	if($_POST['choice']== '2') {
		$pdo->exec("INSERT INTO health_stat VALUES ($id,'2', NOW());");
		}
echo '<meta http-equiv="Refresh" content="0;agebg.php?id='.$id.'" />';
require "end1.php";
?>