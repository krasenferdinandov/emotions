﻿<?php
require "headerbg1.php";
	echo '<br>'.INTRO.'</br>';
	echo '<table><td><tr><center><form id="the_form" style="height: 0vh;overflow:auto" method="POST" action="emotionsbg.php" enctype="multipart/form-data">';
	echo '<input id="-1" class="moving" type="submit" value="'.NEXT.'"></form></center></table></td></tr>';
	require "end1.php";
?>