<?php
require "header.php";
echo '<table class="borders">';
echo '<tr><th>Id</th>';
function interval_to_duration ($interval) {
	return ($interval->h*60 + $interval->i + (floatval($interval->s) / 60));
}
function to_minutes ($duration) {
	return floor($duration) + ($duration - floor($duration)) * 60 / 100;
}
function isInDomain($emotion_search){
	return (floor($emotion_search));
}
$string = array();
$domain = array();
$emotions = array();

$label = $pdo->query("SELECT id, en_name, bg_name FROM emotions");
while($row = $label->fetch(PDO::FETCH_BOTH))
{
	$bg_name = $row['en_name'];
	$emotions[$row['id']] ='<a title="'.quot($row['bg_name']).'">'. $bg_name.'</a>';
}

$statement = $pdo->query("SELECT id, string_id FROM emotions");
while($row = $statement->fetch(PDO::FETCH_BOTH))
{
	$string[$row['id']] = $row['string_id'];
		
}

$statement1 = $pdo->query("SELECT * FROM domains s, emotions sc WHERE sc.domain_id = s.id ");
while($row = $statement1->fetch(PDO::FETCH_BOTH))
{
	$domain[$row['id']] = $row['domain_id'];
	
}
for($i=0;$i<DOMAINS_NUMBER;$i++){
	$domain_data = $pdo->query("select en_name, bg_name from domains where id = ". $i . "");
	
	$name = "WRONG";
	while($r = $domain_data->fetch(PDO::FETCH_BOTH))
	{
		$en_name = $r["en_name"];
		$bg_name = $r["bg_name"];
	}
    echo '<td><center>F'.$i.'_'.$en_name.'_'.$bg_name.'</center></td>';
	//echo '<td><center>F'.$i.'_'.$en_name.'</center></td>';
	//echo '<td><center>'.$bg_name.'</center></td>';
	//echo '<td><center>F'.$i.'</center></td>';
}
//------------------>
for($i=0;$i<THEMES_NUMBER;$i++){
	$script_data = $pdo->query("select en_name, bg_name from statements where id = ". $i . "");
		
	$name = "WTF";
	while($r = $script_data->fetch(PDO::FETCH_BOTH))
	{
		$en_name = $r["en_name"];
		$bg_name = $r["bg_name"];
	}
    echo '<td><center>T'.$i.'_'.$en_name.'_'.$bg_name.'</center></td>';
    //echo '<td><center>'.$bg_name.'</center></td>';
	//echo '<td><center>T'.$i.'</center></td>';
}
for($i=0;$i<MINISCRIPTS_NUMBER;$i++){
	$miniscript_data = $pdo->query("select en_name, bg_name from miniscripts where id = ". $i . "");
		
	$name = "WTF";
	while($r = $miniscript_data->fetch(PDO::FETCH_BOTH))
	{
		$en_name = $r["en_name"];
		$bg_name = $r["bg_name"];
	}
    echo '<td><center>S'.$i.'_'.$en_name.'_'.$bg_name.'</center></td>';
    //echo '<td><center>'.$bg_name.'</center></td>';
	//echo '<td><center>S'.$i.', '.$en_name.', '.$bg_name.'</center></td>';
	//echo '<td><center>S'.$i.'</center></td>';
}
/*echo '<td><center><b>Брой разпознати</b></center></td>';
echo '<td><center><b>Брой семейства</b></center></td>';
echo '<td><center><b>Брой положителни</b></center></td>';
echo '<td><center><b>Брой отрицателни</b></center></td>';
echo '<td><center><b>Брой теми</b></center></td>';
echo '<td><center><b>Брой сценарии</b></center></td>';
echo '<td><center><b>Потискане</b></center></td>';
echo '<td><center><b>Преоценка</b></center></td>';
echo '<td><center><b>Афективно управление</b></center></td>';
echo '<td><b>Начало</b></td>';
echo '<td><b>Край</b></td>';
echo '<td><center><b>Общо време за участие (в минути, Bassili 1996)</b><center></td>';
echo '<td><center><b>Време за идентификация на всички емоции (в минути, Bassili 1996)</b><center></td>';
echo '<td><center><b>Време за идентификация на положителни емоции (в минути, Bassili 1996)</b><center></td>';
echo '<td><center><b>Време за идентификация на отрицателни емоции (в минути, Bassili 1996)</b><center></td>';
echo '<td><center><b>Време за идентификация на теми (в минути, Bassili 1996)</b><center></td>';
echo '<td><center><b>Време за идентификация на сценарии (в минути, Bassili 1996)</b><center></td>';*/
echo '</tr>';

$count_data = $pdo->query("SELECT id FROM states_stat ORDER BY id");

$count = 0;
$last = -1;
$id_array = array();
while($r = $count_data->fetch(PDO::FETCH_BOTH))
{
	if($r['id'] != $last)
	{
		$last = $r['id'];
		$id_array[] = $last;
		$count++;
	}
}

for($k = 0; $k<$count; $k++)
{ 
	$current_id = $id_array[$k];
	$emotion_row_array = array();
	$domain_row_array = array();
	$miniscripts_row_array = array();
	$scripts_row_array = array();
	
//$data = $pdo->query("SELECT * FROM emotions_stat WHERE id = $current_id LIMIT 1");
//$data = $pdo->query("SELECT * FROM id_stat WHERE id = $current_id LIMIT 1");
//$data = $pdo->query("SELECT * FROM states_stat WHERE id = $current_id LIMIT 1");
$data = $pdo->query("SELECT * FROM gros_stat WHERE id = $current_id LIMIT 1");
//$data = $pdo->query("SELECT * FROM status_stat WHERE id = $current_id LIMIT 1");
$r = $data->fetch(PDO::FETCH_BOTH);
$id = $r['id'];
if(!isset($id)) continue;
	for($i = 0; $i<EMOTIONS_NUMBER; $i++)
	{
		$emotion_row_array[] = 0;
	}
	$domains_category_array ['pos'] = array();
	$domains_category_array ['neg'] = array();
	for($i = 0; $i<DOMAINS_NUMBER; $i++)
	{
		$domain_row_array[] = 0;
		$domains_category_array ['pos'][] = 0;
		$domains_category_array ['neg'][] = 0;
	}
	for($i = 0; $i<THEMES_NUMBER; $i++)
	{
		$scripts_row_array[] = 0;
	}
	for($i = 0; $i<MINISCRIPTS_NUMBER; $i++)
	{
		$miniscripts_row_array[] = 0;
	}
	$count_e=0;	
	$data = $pdo->query("SELECT emotion_id FROM emotions_stat WHERE id = $current_id");
	while($r = $data->fetch(PDO::FETCH_BOTH)) {
			
		$e_id = $r['emotion_id'];
		if($e_id!=-1) $emotion_row_array[$e_id] = 1;
		if($e_id != -1)$domain_row_array[$domain[$e_id]] = 1;
		
		$count_e+=1;
	}
	
	
	$count_s=0;	
	$data_s = $pdo->query("SELECT * FROM states_stat WHERE id = $current_id");
	while($r = $data_s->fetch(PDO::FETCH_BOTH)) {
		$si_id = $r['state_id'];
				
		if($si_id!=-1) $scripts_row_array[$si_id] = 1;
		$count_s+=1;
	}
	
	$count_m=0;	
	$data = $pdo->query("SELECT miniscript_id FROM miniscripts_stat WHERE id = $current_id");
	while($r = $data->fetch(PDO::FETCH_BOTH)) {
		$mi_id = $r['miniscript_id'];
		if($mi_id!=-1) $miniscripts_row_array[$mi_id] = 1;
		$count_m+=1;
	}
//------------------------>
$posi = '';
$nega = '';
$manag = 0;
$sum_pos=0;$count_pos=0;
$sum_neg=0;$count_neg=0;
$sel_emotions = $pdo->query("SELECT * FROM emotions_stat WHERE id=$current_id");
while($r = $sel_emotions->fetch(PDO::FETCH_BOTH)){
	$e_id=$r['emotion_id'];
	$e_sl=$r['e_slider'];
	
	$data = $pdo->query("SELECT domain_id, valence_id, string_id, tension_id FROM emotions WHERE id = $e_id LIMIT 1");
	$r = $data->fetch(PDO::FETCH_BOTH);
	$domain_id = intval($r['domain_id']);
	$dimension_id = $r['valence_id'];
	$e_string = $r['string_id'];
	$e_tension = $r['tension_id'];
	
		if ($e_string == 0){			
		$density= (($e_sl*0.4)+$e_tension);
		}
		else if($e_string == 1){
		$density=(($e_sl*0.6)+$e_tension);
		}
		else if($e_string == 2){
		$density=(($e_sl*0.8)+$e_tension);
		}
		
		if($dimension_id == 0){
			$sum_pos+=$density;
			$count_pos+=1;
		}
		if($dimension_id == 1){
			$sum_neg+=$density;
			$count_neg+=1;
		}
}		
$score_neg=scores_level($sum_neg, $count_neg);
$score_pos=scores_level($sum_pos, $count_pos);
$score_group=$score_neg.$score_pos;

$data = $pdo->query("SELECT id,bg_name,bg_desc FROM management WHERE score_group LIKE '%$score_group%'");
$r = $data->fetch(PDO::FETCH_BOTH);
$id_manag = 99;

if ($r){
	$id_manag = $r['id'];
	$bg_name = $r['bg_name'];
	$bg_desc = $r['bg_desc'];
}else{
	$bg_name='';
	$bg_desc='';
}
$posi = percent($sum_pos, $sum_pos+$sum_neg);
$nega = percent($sum_neg, $sum_pos+$sum_neg);
//---------------------------->
echo '<tr><td><center>'.$current_id.'</center></td>';

for($i=0;$i<DOMAINS_NUMBER;$i++)
		if($domain_row_array[$i] != 1)
			echo '<td><center>0</center></td>';
		else echo '<td><center><b>1<b/></center></td>';
for($i=0;$i<THEMES_NUMBER;$i++)
		if($scripts_row_array[$i] != 1)
			echo '<td><center>0</center></td>';
		/*else {
			$data_t = $pdo->query("SELECT * FROM states_stat WHERE id = " . $current_id . "");
			while($rs = $data_t->fetch(PDO::FETCH_BOTH)) {
			$s_id = $rs['state_id'];
			if($s_id!=$i)continue;
			$s_sl = $rs['s_slider'];
			}
			echo '<td><center><b>'.$s_sl.'<b/></center></td>';
		}*/
		else echo '<td><center><b>1<b/></center></td>';
		
for($i=0;$i<MINISCRIPTS_NUMBER;$i++)
		if($miniscripts_row_array[$i] != 1)
			echo '<td><center>0</center></td>';
		else echo '<td><center><b>1<b/></center></td>';
//---------------------------->
$data = $pdo->query("SELECT emotion_id FROM emotions_stat WHERE id = $current_id");
	while($r = $data->fetch(PDO::FETCH_BOTH)) {
			
		$e_id = $r['emotion_id'];
		if($e_id!=-1) $emotion_row_array[$e_id] = 1;
		if($e_id != -1)$domain_row_array[$domain[$e_id]] = 1;
		$count_em+=1;
		
		{
			$emotion = $pdo->query("SELECT * FROM emotions WHERE id = $e_id")->fetch(PDO::FETCH_BOTH);
			if ($emotion['valence_id'] == 0)
				$domains_category_array ['pos'][$domain[$e_id]] = 1;
			else
				$domains_category_array ['neg'][$domain[$e_id]] = 1;
		}
	}
//---------------------------->
$count_p=0;	
	$data = $pdo->query("SELECT label FROM photoes_stat WHERE id = $current_id");
	while($r = $data->fetch(PDO::FETCH_BOTH)) {
		$p_id = $r['label'];
		if($p_id != "0") $count_p+=1;

	}
//---------------------------->
$max_photoes = "0000-00-00 00:00:00";
$min_photoes = "9999-99-99 99:99:99";

$data = $pdo->query("SELECT timing_label FROM photoes_stat WHERE id = $current_id");
while($r = $data->fetch(PDO::FETCH_BOTH))
{
	$time = $r['timing_label'];
	if ($time == '') continue;
	$min_photoes = min($min_photoes, $time);
	$max_photoes = max($max_photoes, $time);
}

$max_emotions = "0000-00-00 00:00:00";
$min_emotions = "9999-99-99 99:99:99";

$data = $pdo->query("SELECT timing FROM emotions_stat WHERE id = $current_id");
while($r = $data->fetch(PDO::FETCH_BOTH))
{
	$time = $r['timing'];
	if ($time == '') continue;
	$min_emotions = min($min_emotions, $time);
	$max_emotions = max($max_emotions, $time);
}

$max_emotions_pos = "0000-00-00 00:00:00";
$min_emotions_pos = "9999-99-99 99:99:99";
$max_emotions_neg = "0000-00-00 00:00:00";
$min_emotions_neg = "9999-99-99 99:99:99";
$data = $pdo->query("SELECT timing, valence_id FROM emotions t1 INNER JOIN emotions_stat t2 ON t1.id = t2.emotion_id WHERE t2.id = $current_id AND t1.valence_id = 0");
while($r = $data->fetch(PDO::FETCH_BOTH))
{
	$time = $r['timing'];
	if ($time == '') continue;
	$min_emotions_pos = min($min_emotions_pos, $time);
	$max_emotions_pos = max($max_emotions_pos, $time);
}
$data = $pdo->query("SELECT timing, valence_id FROM emotions t1 INNER JOIN emotions_stat t2 ON t1.id = t2.emotion_id WHERE t2.id = $current_id AND t1.valence_id = 1");
while($r = $data->fetch(PDO::FETCH_BOTH))
{
	$time = $r['timing'];
	if ($time == '') continue;
	$min_emotions_neg = min($min_emotions_neg, $time);
	$max_emotions_neg = max($max_emotions_neg, $time);
}

$max_states = "0000-00-00 00:00:00";
$min_states = "9999-99-99 99:99:99";

$data = $pdo->query("SELECT timing FROM states_stat WHERE id = $current_id");
while($r = $data->fetch(PDO::FETCH_BOTH))
{
	$time = $r['timing'];
	if ($time == '') continue;
	$min_states = min($min_states, $time);
	$max_states = max($max_states, $time);
}

$max_scripts = "0000-00-00 00:00:00";
$min_scripts = "9999-99-99 99:99:99";

$data = $pdo->query("SELECT time FROM miniscripts_stat WHERE id = $current_id");
while($r = $data->fetch(PDO::FETCH_BOTH))
{
	$time = $r['time'];
	if ($time == '') continue;
	$min_scripts = min($min_scripts, $time);
	$max_scripts = max($max_scripts, $time);
}

$duration_photoes = 0;
$duration_emotions = 0;
$duration_emotions_pos = 0;
$duration_emotions_neg = 0;
$duration_states = 0;
$duration_scripts = 0;
//////////////TODO: SELECT * FROM miniscripts_stat t1 INNER JOIN miniscripts2_stat t2 ON t1.id = t2.id WHERE t1.miniscript_id=t2.miniscript_id
try {
	$datetime1 = new DateTime($min_photoes);
	$datetime2 = new DateTime($max_photoes);
	$duration_photoes = interval_to_duration($datetime1->diff($datetime2));
	
}catch (Exception $ex) {}try{
	$datetime3 = new DateTime($min_emotions);
	$datetime4 = new DateTime($max_emotions);
	$duration_emotions = interval_to_duration($datetime3->diff($datetime4));
	
}catch (Exception $ex) {}try{
	$datetime5 = new DateTime($min_emotions_pos);
	$datetime6 = new DateTime($max_emotions_pos);
	$duration_emotions_pos = interval_to_duration($datetime5->diff($datetime6));
	
}catch (Exception $ex) {}try{
	$datetime7 = new DateTime($min_emotions_neg);
	$datetime8 = new DateTime($max_emotions_neg);
	$duration_emotions_neg = interval_to_duration($datetime7->diff($datetime8));
	
}catch (Exception $ex) {}try{
	$datetime9 = new DateTime($min_states);
	$datetime10 = new DateTime($max_states);
	$duration_states = interval_to_duration($datetime9->diff($datetime10));
	
}catch (Exception $ex) {}try{
	$datetime11 = new DateTime($min_scripts);
	$datetime12 = new DateTime($max_scripts);
	$duration_scripts = interval_to_duration($datetime11->diff($datetime12));
	
}catch (Exception $ex) {}try{
	$datetime13 = new DateTime($min_scripts2);
	$datetime14 = new DateTime($max_scripts2);
	$duration_scripts2 = interval_to_duration($datetime13->diff($datetime14));
	
}catch (Exception $ex) {}try{
	$datetime15 = new DateTime($min_gros);
	$datetime16 = new DateTime($max_gros);
	$duration_gros = interval_to_duration($datetime15->diff($datetime16));
}catch (Exception $ex) {}
$duration = $duration_emotions + $duration_states + $duration_scripts;
$duration1 = $duration_emotions;
$duration2 = $duration_states;
$duration3 = $duration_scripts;

	/*if ($current_id == 662)
	{
		echo $min_photoes . '; ' . $max_photoes . '<br>';
		echo $min_states . '; ' . $max_states . '<br>';
		echo $min_scripts . '; ' . $max_scripts . '<br>';
		echo $min_gros . '; ' . $max_gros . '<br>';
		
		echo to_minutes ($duration) . '=' . $duration_photoes . '+' . $duration_emotions . '+' . $duration_states . '+' . $duration_scripts . '+' . $duration_scripts2 . '+' . $duration_gros . '<br><br>';

	}*/

/*$string0 = to_minutes ($duration); 
$string0 = str_replace(".", ",", $string0); 
echo '<td><center>'.$string0.'</center></td>';// Време за участие, в минути.

$string1 = to_minutes ($duration1); 
$string1 = str_replace(".", ",", $string1); 
echo '<td><center>'.$string1.'</center></td>';// Време за участие, в минути.

$string2 = to_minutes ($duration_emotions_pos); 
$string2 = str_replace(".", ",", $string2); 
echo '<td><center>'.$string2.'</center></td>';// Време за участие, в минути.

$string3 = to_minutes ($duration_emotions_neg); 
$string3 = str_replace(".", ",", $string3); 
echo '<td><center>'.$string3.'</center></td>';// Време за участие, в минути.

$string4 = to_minutes ($duration2); 
$string4 = str_replace(".", ",", $string4); 
echo '<td><center>'.$string4.'</center></td>';// Време за участие, в минути.

$string5 = to_minutes ($duration3); 
$string5 = str_replace(".", ",", $string5); 
echo '<td><center>'.$string5.'</center></td>';// Време за участие, в минути.*/
//---------------------------->
echo '</tr>';
}

echo '</table>';
require "end.php";
?>