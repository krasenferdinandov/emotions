﻿<?php
date_default_timezone_set("Europe/Sofia");
require "headerbg1.php";
	$timeNow = time();
	$dt = new DateTime();
	$dt->setTimestamp($timeNow);
	//echo CHOOSE_EMOTIONS.'<br><p align="left">При преценката използвай тези стандарти:<br>'.COMMON.'</br></p></th>';
	echo CHOOSE_EMOTIONS;
	echo '<form id="the_form" style="height: 0vh;overflow:auto" method="POST" action="durationbg.php" enctype="multipart/form-data">';
	echo '<input type="hidden" id="startTime" name="timeStarted" value="'.$dt->format("Y-m-d H:i:s").'">';
	$data = $pdo->query("SELECT id, bg_name, en_name, domain_id FROM feelings ORDER BY id ASC");
	require "js/star.html";
	while($row = $data->fetch(PDO::FETCH_BOTH)){
		echo '<label id="'.$row['id'].'" class="moving" title="'.$row['en_name'].'">';
		echo '<input class="timed" type="radio" name="'. $row['domain_id'] . '" value="'. $row['id'] .'">'.$row['bg_name'];
		//echo '<input class="timed" type="checkbox" name="'. $row['domain_id'] . '" value="'. $row['id'] .'">'.$row['bg_name'];
		//echo '<input class="timed" type="checkbox" name="'. $row['id'] . '" value="'. $row['id'] .'">'.$row['bg_name'];
		echo '</label><br/>';
	}
	echo '<input id="-1" class="moving" type="submit" value="'.NEXT.'"></form>';
	//Джурка емоциите в началото
	//echo '<script>start_moving ()</script>';
	//Подрежда емоциите в началото
	echo '<script>place_words()</script>';
	echo '<script src="js/collectTiming.js"></script>';
	require "end1.php";
?>