<?php
require "header1.php";
$domain = array();
$emotions = array();
$sum_pos=0;$count_pos=0;
$sum_neg=0;$count_neg=0;
$sel_emotions = array();

//---------------------------->
if(!array_key_exists('id', $_GET)){
	die();
}
$id = $_GET['id'];
validateInt($id);

$emotion_row_array = array();
$domain_row_array = array();
	
for($i = 0; $i<EMOTIONS_NUMBER; $i++)
	{
		$emotion_row_array[] = 0;
	}
	$domains_category_array ['pos'] = array();
	$domains_category_array ['neg'] = array();
	for($i = 0; $i<DOMAINS_NUMBER; $i++)
	{
		$domain_row_array[] = 0;
		$domains_category_array ['pos'][] = 0;
		$domains_category_array ['neg'][] = 0;
	}

$statement1 = $pdo->query("SELECT * FROM domains s, feelings sc WHERE sc.domain_id = s.id ");
while($row = $statement1->fetch(PDO::FETCH_BOTH))
{
	$domain[$row['id']] = $row['domain_id'];
}

$data = $pdo->query("SELECT emotion_id FROM duration_stat WHERE id = $id");
	while($r = $data->fetch(PDO::FETCH_BOTH)) {
			
		$e_id = $r['emotion_id'];
		if($e_id!=-1) $emotion_row_array[$e_id] = 1;
		if($e_id != -1)$domain_row_array[$domain[$e_id]] = 1;
		
		{
			$emotion = $pdo->query("SELECT * FROM feelings WHERE id = $e_id")->fetch(PDO::FETCH_BOTH);
			if ($emotion['valence_id'] == 0)
				$domains_category_array ['pos'][$domain[$e_id]] = 1;
			else
				$domains_category_array ['neg'][$domain[$e_id]] = 1;
		}
	}
	$positives = array_sum($domains_category_array['pos']); 
	$negatives = array_sum($domains_category_array['neg']); 
	$count_e = array_sum($domain_row_array);

echo '<input type="hidden" name="id" value="'.$id.'">';

//Показва съобщение за резултата с текущото ID
echo'<center><b>'.ID.'<br></b>'.TIP.'<b>'.$id.'</b><center/><br>';

$sum_pos=0;$count_pos=0;
$sum_neg=0;$count_neg=0;
$sel_emotions = $pdo->query("SELECT * FROM duration_stat WHERE id=$id");
while($r = $sel_emotions->fetch(PDO::FETCH_BOTH)){
	$e_id=$r['emotion_id'];
	$e_sl=$r['e_slider'];
	
	$data = $pdo->query("SELECT domain_id, valence_id FROM feelings WHERE id = $e_id LIMIT 1");
	$r = $data->fetch(PDO::FETCH_BOTH);
	$domain_id = intval($r['domain_id']);
	$valence_id = $r['valence_id'];
		
		if($valence_id == 0){
			$sum_pos+=$e_sl;
			$count_pos+=1;
		}
		if($valence_id == 1){
			$sum_neg+=$e_sl;
			$count_neg+=1;
		}
	$data = $pdo->query("SELECT domain_id, valence_id, en_name, bg_name FROM feelings WHERE id = $e_id LIMIT 1");
	$r = $data->fetch(PDO::FETCH_BOTH);
	$domain_id = intval($r['domain_id']);
	$en_name = $r['en_name'];
	$bg_name = $r['bg_name'];
	$valence_id = $r['valence_id'];
	$density=$e_sl;
}
//---------------------------->
$max_emotions = "0000-00-00 00:00:00";
$min_emotions = "9999-99-99 99:99:99";
$data = $pdo->query("SELECT timing FROM duration_stat WHERE id = $id");
while($r = $data->fetch(PDO::FETCH_BOTH))
{
	$time = $r['timing'];
	if ($time == '') continue;
	$min_emotions = min($min_emotions, $time);
	$max_emotions = max($max_emotions, $time);
}
try {
	$datetime1 = new DateTime($min_emotions);
	$datetime2 = new DateTime($max_emotions);
	
} 
catch (Exception $ex) {}

$max_themes = "0000-00-00 00:00:00";
$min_themes = "9999-99-99 99:99:99";
$data = $pdo->query("SELECT timing FROM states_stat WHERE id = $id");
while($r = $data->fetch(PDO::FETCH_BOTH))
{
	$time = $r['timing'];
	if ($time == '') continue;
	$min_themes = min($min_themes, $time);
	$max_themes = max($max_themes, $time);
}
try {
	$datetime5 = new DateTime($min_themes);
	$datetime6 = new DateTime($max_themes);
	
} 
catch (Exception $ex) {}

$max_niesen = "0000-00-00 00:00:00";
$min_niesen = "9999-99-99 99:99:99";

$data = $pdo->query("SELECT timing FROM niesen_stat WHERE id = $id");
while($r = $data->fetch(PDO::FETCH_BOTH))
{
	$time = $r['timing'];
	if ($time == '') continue;
	$min_niesen = min($min_niesen, $time);
	$max_niesen = max($max_niesen, $time);
}

try{
	$datetime7 = new DateTime($min_niesen);
	$datetime8 = new DateTime($max_niesen);
	
}
catch (Exception $ex) {}

$start = "0000-00-00 00:00:00";
$data = $pdo->query("SELECT start FROM duration_timing WHERE id = $id");
while($r = $data->fetch(PDO::FETCH_BOTH))
{
	$start = $r['start'];
	$datetime3 = new DateTime($start);
}
$end = "0000-00-00 00:00:00";
$data = $pdo->query("SELECT end FROM duration_timing WHERE id = $id");
while($r = $data->fetch(PDO::FETCH_BOTH))
{
	$end = $r['end'];
	$datetime4 = new DateTime($end);
	
}
$data = $pdo->query("SELECT choice FROM gender_stat WHERE id = $id");
while($r = $data->fetch(PDO::FETCH_BOTH))
{
	$gender = $r['choice'];
}
$data = $pdo->query("SELECT choice FROM age_stat WHERE id = $id");
while($r = $data->fetch(PDO::FETCH_BOTH))
{
	$age = $r['choice'];
}
$data = $pdo->query("SELECT choice FROM health_stat WHERE id = $id");
while($r = $data->fetch(PDO::FETCH_BOTH))
{
	$health = $r['choice'];
}
$emotions_selection = interval_to_duration($datetime1->diff($datetime2));
$slider_assessment = interval_to_duration($datetime3->diff($datetime4));
$themes_selection = interval_to_duration($datetime5->diff($datetime6));
$duration_niesen = interval_to_duration($datetime7->diff($datetime8));
$latency = $emotions_selection + $slider_assessment + $themes_selection + $duration_niesen;
//---------------------------------------------------->

//---------------------------------------------------->
echo '<table><tr colspan="4"><td><center><b>RESULTS:</b></center></td></tr>';
$string1 = round ((($count_pos-$count_neg)), 2);
//$string1 = round ((($sum_pos-$sum_neg)), 2);
$string1 = str_replace(".", ",", $string1);
echo '<tr><td colspan="2" style="border: 0px solid #c0c0c0;"><b>Balance:</b></td><td>'.$string1.'</td><td><input type="button" data-id="balance" class="show" value="norms"></td></tr>';// Афективен баланс (Bradburn 1969)
echo '<tr><td colspan="2" style="border: 0px solid #c0c0c0;"><label class="desc-res4" style="display: none;" id="balance">If index is equal to 0, that means a perfect balance between the positive and negative emotions.If index is higher than 0, means that positive emotions overcome the negative ones and a state of happiness is achieved longer than suffering. Average expectation is to be about 0,86. High values are up to 3,5 and lower estimates are about -1,8. Minimum is -10 and the maximum is 10. Norms are based on 913 volunteers.</label></td></tr>';

$string2 = round (($negatives > $positives) ?(($sum_neg*$negatives)) :0 ,3);
$string2 = str_replace(".", ",", $string2);
echo '<tr><td colspan="2" style="border: 0px solid #c0c0c0;"><b>Misery index:</b></td><td>'.$string2.'</td><td><input type="button" data-id="misery" class="show" value="norms"></td></tr>';// б. Misery index (Kahneman &2006)
echo '<tr><td colspan="2" style="border: 0px solid #c0c0c0;"><label class="desc-res4" style="display: none;" id="misery">If index is equal to 0, than you accept yourself as a happy person.If index is higher than 0, that means your negative emotions are not only more than positives but last longer enough to feel unhappy. Average expectation is index to be about 5,6; higher estimates are more than 13. Minimum is 0 scores and maximum is 360. Norms are based on 913 volunteers. </label></td></tr>';
//--------->BASSILI 1996
$string0 = round (to_minutes ($latency), 2); 
$string0 = str_replace(".", ",", $string0); 
echo '<tr><td><b>Time spent </b>(mm, ss):</td><td>'.$string0.'</td><td><center></center></td></tr></table>';// Време за участие, в минути.
//--------->
//Demorest --> Themes
$table_result = '<table class="borders"><tr><th colspan="2"><center>List of selected themes:<center/></th><center/><br/></tr>';
$sel_states = $pdo->query("SELECT * FROM states_stat WHERE id=$id");
while($r3 = $sel_states->fetch(PDO::FETCH_BOTH)){
	$s_id=$r3['state_id'];
	$s_sl=$r3['s_slider'];
	
	
	$data_s = $pdo->query("SELECT en_name, bg_name FROM statements WHERE id = $s_id LIMIT 1");
	$rs = $data_s->fetch(PDO::FETCH_BOTH);
	$bg_name = $rs['bg_name'];
	$en_name = $rs['en_name'];

	$table_result .= '<tr><td style="border: 1px solid #c0c0c0;"><a title="'.quot($bg_name).'"><b>* '.quot($en_name).'</a></td>';
	$table_result .= '<td style="border: 1px solid #c0c0c0;">Preference:<b> '.$s_sl.'</b></td></tr>';
}
echo $table_result .= '<table class="borders"><tr><td colspan="2"><center><center/></td><center/></tr><center/></table>';
//--------->NIESEN ET AL. 2019

$sum_pqm=0;
$sum_nqm=0;
$table_result = '<table class="borders"><tr><th colspan="2"><center>Social desirability bias:<center/></th><center/><br/></tr>';
$sel_desire = $pdo->query("SELECT * FROM niesen_stat WHERE id=$id");
while($rd = $sel_desire->fetch(PDO::FETCH_BOTH)){
	$n_id=$rd['state_id'];
	$n_sl=$rd['s_slider'];

	
	$data_desire = $pdo->query("SELECT axis_id FROM niesen WHERE id = $n_id LIMIT 1");
	$rd = $data_desire->fetch(PDO::FETCH_BOTH);
	$axisn_id = intval($rd['axis_id']);
	
		if($axisn_id == 0){
			$sum_pqm+=$n_sl/3;
		}
		if($axisn_id == 1){
			$sum_nqm+=$n_sl/3;
		}
}
$string5 = round (($sum_pqm), 2); 
$string5 = str_replace(".", ",", $string5);
$table_result .= '<tr><td colspan="2" style="border: 0px solid #c0c0c0;"><b>Positives maximizing:</b></td><td>'.$string5.'</td><td><input type="button" data-id="maximizing" class="show" value="norms"></td></tr>';
$table_result .= '<tr><td colspan="2" style="border: 0px solid #c0c0c0;"><label class="desc-res4" style="display: none;" id="maximizing">Mean is about 3,5. High scores are about 4,5 which means a tendency to exagerate personal strengths and positives; lower is 2,4 which means personal humility or desire to underestimate personal positives; Min=0, Max=5. Norms are based on 864 bulgarian volunteers.</label></td></tr>';

$string6 = round (($sum_nqm), 2); 
$string6 = str_replace(".", ",", $string6);
$table_result .= '<tr><td colspan="2" style="border: 0px solid #c0c0c0;"><b>Negatives minimizing:</b></td><td>'.$string6.'</td><td><input type="button" data-id="minimizing" class="show" value="norms"></td></tr>';
$table_result .= '<tr><td colspan="2" style="border: 0px solid #c0c0c0;"><label class="desc-res4" style="display: none;" id="minimizing">Mean is about 1,5. High scores are about 2,2 which is a lower limit of honesty about personal negatives; lower is 0,7 which means a clear intention to hide personal negatives; Min=0, Max=5. Norms are based on 864 bulgarian volunteers.</label></td></tr>';//--------->//DIENER ET AL. 1985

//------------->
echo $table_result .= '<table class="borders"><tr><td colspan="2"><center><center/></td><center/></tr><center/></table>';

echo ''.CONTRIBUTION.'';
require ("js/showText.js");
require "end1.php";
?>