function toggle_slider (id) {
	var labels = document.querySelectorAll ('[data-label=s_slider_' + id + ']');
	var value = document.querySelectorAll ('[data-for=s_slider_' + id + ']')[0];
	var td = document.querySelectorAll ('[data-for=checkit' + id + ']')[0];
	var checkbox = document.getElementById('checkit' + id);
	console.log(td);
	console.log(td.style.display);
	if (checkbox.checked) {
		td.style.display = 'table-cell';
		td.style.opacity = 1;
		value.style.display = 'table-cell';
		value.style.opacity = 1;
		
		console.log(value);
		console.log(td);
		
		//value.className += 'slider_text';
		for(var i = 0 ; i < 2 ; i += 1) {
			labels [i].style.display = 'table-cell';
		}
	}
	else {
		td.style.display = 'hidden';
		td.style.opacity = 0;
		value.style.display = 'hidden';
		value.style.opacity = 0;
		//value.className = '';
		for(var i = 0 ; i < 2 ; i += 1) {
			labels [i].style.display = 'hidden';
		}
	}
	/*if (td.innerHTML == '') {
		//td.innerHTML = '<input onchange="showNums();" type="range" name="s_slider_'+ id +'" class="timed s_slider" value="1" min="1" max="9" step="1"/>';
		value.innerHTML = "1";
	}
	else {
		//td.innerHTML = '';
		value.innerHTML = "";
	}*/
}