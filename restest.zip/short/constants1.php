﻿<?php
	$a=5;
	define ("NEXT", 'Go Forward');
	define ("INTRO", '<center><table><tr><td><p class="desc-res3" align="center">THANK YOU FOR CHOOSING TO TAKE PART IN THE SOFT EXPERIMENT.THE FOLLOWING STEPS OF THE TEST REQUIRE TO CONSIDER, SELECT
	AND EVALUATE ONLY THESE EMOTIONS WHICH YOU EXPERIENCE THE MOST FREQUENTLY IN THE LAST MONTH OF YOUR LIFE. USE FOLLOWING SCALE TO CHOOSE YOUR EMOTIONS: 
	<p><br><b>Very rarely</b> (a few times a year); 
	<br><b>Barely</b> (a few times per month);
	<br><b>Occasionally</b> (once in a week);
	<br><b>Regularly</b> (almost every day);
	<br><b>Very often</b> (few times a day).</p></td></tr></table></center>
	<center><table><tr><td><p class="desc-res3" align="center">Then estimate how long the conditions you have selected last. Subsequently, before the end of the test, choose from all the suggested words for feelings only those that correspond to the previously selected emotions. After each marking, assess the level of compliance. Let your answer be as frank as possible. There may be a similarity between what emotions you want to experience and what is actually happening. Try to make your choice closer to what really is as much as you can.
	</td></tr></table></center>');
	define ("CHOOSE_EMOTIONS", '<b><center>FIRST STEP: <br>CHOOSE THE MOST COMMON EXPIRIENCED EMOTIONS (E.G. FOR THE LAST MONTH).</b><center/><br/>');
	define ("CHOOSE_STATES", '<b><a title="These words reflect what are the properties of celebratory, ambivalent and harmatic emotion related types of scenes.">Choose only these words that fits to selected emotions.</b></a>');
	define ("NOT_ENOUGH_OR_TOO_MANY", '<center>Choose at least one emotional state.</center>');	
	define ("HOW_FAST", '<a title="It is about enduring of your own feelings or emotional conditions?">How long these chosen states are passing by?</a>');
	define ("DURING", '1 = up to minute ("Very fast"), 
	<br>2 = few minutes,
	<br>3 = up to an hour,
	<br>4 = few hours,
	<br>5 = up to a day,
	<br>6 = up to an week,
	<br>7 = few weeks,
	<br>8 = up to a month,
	<br>9 = few moths,
	<br>10 = in years ("Very slowly").');
	define ("FASTEST", '<a title="It means that your condition is very easy to overcome and lasts very short time.">Very Quickly</a>');
	define ("SLOWEST", '<a title="It means that your condition is difficult to overcome and lasts long time.">Very Slowly</a>');
	define ("ALWAYS", 'Always');
	define ("RARE", 'Very rarely');
	define ("CONTRIBUTION", '<p class="desc-res3" align="right"><a title="All members of programming team have right to change the code in order to improve or contribute to further development of testing model only with agreement of the author."><b>PHP, MySQL & JS: Hristo Venev, Hristo Minkov, Kristian Cuklev, Alex Tsvetanov, Dimo Chanev, Anton Denev and Valyo Yolovski.</p><small>GPL v.3 Copyrights &copy; 2015 Krasen Ferdinandov, psychologist.</b></small></a>');	
	define ("RESULTS", '<a title=" Qualities And Properties Of Some Scientific Categories: The percent, shown below means different aspects of personal emotional style, e.g. basic affective scripts, proportion in personal sentimentality and expectations, emotional amplification and magnification of personal life choices and habits: what is the role of emotions and proportion in and their influence over your decision-making everyday not only about very important life issues, but also about insignificant at first glance behavioral and interpersonal matters, enlightened by different psychological dimensions."><b>Choosen emotions:<b/></a>');		
	define ("ID", 'Thank you for the participation!');
	define ("TIP", 'If you want to check your results, copy this internet adress:<br><b>https://testrain.info/short/profile.php?id=</b>');
	define ("EMOTIONS_NUMBER", 90);
	define ("CHOICE_NUMBER", 2);		
	define ("DOMAINS_NUMBER", 10);
	define ("THEMES_NUMBER", 24);
	define ("STATES_NUMBER_1", 6);

	function redirect($url){
		if (headers_sent()){
			die('<script type="text/javascript">window.location.href="' . $url . '";</script>');
		}else{
			header('Location: ' . $url);
			die();
		}    
	} // to headers!!!!!
	function validateInt($a){
		if(!is_numeric($a)){
			header("HTTP/1.1 400 Bad Request");
			exit();
		}
	}
	function quot($text){
		return htmlspecialchars($text);
	}
	function interval_to_duration ($interval) {
	return ($interval->h*60 + $interval->i + (floatval($interval->s) / 100));
	}
	function to_minutes ($duration) {
		return floor($duration) + ($duration - floor($duration)) * 60 / 100;
	}
	function ed ($category, $total)
	{
		if($category>0 && $total > 0)
			return -1*($category/$total)*log($category/$total);
		else
			return 0;
	}
	function isInDomain($emotion_search){
		return (floor($emotion_search));
	}
?>