<?php
date_default_timezone_set("Europe/Sofia");
require_once "constantsbg1.php";
require_once "db_pass1.php";
if (array_key_exists('timeStarted', $_POST))
	{
		echo '<input type="hidden" name="timeStarted" value="'.$_POST['timeStarted'].'">';
	} 
	else
	{
		redirect ('emotionsbg.php');
	}

echo '<input type="hidden" name="id" value="'.$_POST['id'].'">';
$id = $_POST['id'];
//echo '<br>ID: ' . $_POST['id'];
for($a = 0; $a<THEMES_NUMBER; $a++){
	if(isset($_POST['state_'.$a])){
		$s_slider = intval($_POST['s_slider_'.$a]);
		validateInt($s_slider);
		$timing = $_POST['time-state_' . $a];
		//echo $a . ' -> ' . $timing . '<br/>';
		$pdo->exec("INSERT INTO states_stat VALUES ($id,$a,$s_slider,'$timing');");
	}
}
echo '<meta http-equiv="Refresh" content="0;niesenbg.php?id='.$id.'" />';
require "end1.php";
?>