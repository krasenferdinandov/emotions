<?php
require "headerbg1.php";
$timeNow = time();
	$dt = new DateTime();
	$dt->setTimestamp($timeNow);
echo '<form id="the_form" method="POST" action="intodb2bg.php" enctype="multipart/form-data" onSubmit="return checkboxesOkay(this);">';
if (array_key_exists('id', $_GET))
	{
		$id = $_GET['id'];
		validateInt($id);
		//echo '<br>ID: ' . $id;
	} 
echo '<input type="hidden" name="id" value="'.$id.'">';
echo '<input type="hidden" id="startTime" name="timeStarted" value="'.$dt->format("Y-m-d H:i:s").'">';

$table = '';
$table .= '<table>';
echo '<center>';
$table .= '</tr>';
echo '<p><b>ТРЕТА СТЪПКА:</b><br/>'.CHOOSE_STATES . '</center>';
echo '<center style="position: absolute; left: 40%; text-align: left;">';

echo '<table class="borders">';
$data = $pdo->query("SELECT * FROM statements");
while($row = $data->fetch(PDO::FETCH_BOTH)){
	$id=$row["id"];
	$bg_name=$row["bg_name"];
	$en_name=$row["en_name"];
	echo '<p><input style="display: inline;" class="timed for_slider" id="checkit'.$id.'" type="checkbox" name="state_'.$id.'" value="1" onchange="toggle_slider (' . $id . ');">';
	echo '<a title="'.quot($en_name).'"><label for="checkit'.$id.'">'.$bg_name.'</label></p>';
	echo '<table class="borders"><tr><td style="font-weight: bold; text-align:center; width: 20px; display: none;" data-for="s_slider_' . $id . '" ></td>';
	echo '<td style="display: none;" data-label="s_slider_' . $id . '">Незначително</td>';
	echo '<td style="display: none;" data-for="checkit' . $id . '"></td>';
	echo '<td style="display: none;" data-label="s_slider_' . $id . '">Напълно</td></tr></table>';
}
$table .= '<tr><td><p><input type="submit" value="'.NEXT.'"/></td></tr></table>';
echo $table;
echo '<script src="js/add_slider.js"></script>';
echo '<script src="js/collectTiming.js"></script>';
require "js/numbers.js";
require "end1.php";	
?>