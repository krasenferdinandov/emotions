<?php
require "headerbg1.php";
echo '<form id="the_form" method="POST" action="intodb8.php" enctype="multipart/form-data" onSubmit="return checkboxesOkay(this);">';
if (array_key_exists('id', $_GET))
	{
		$id = $_GET['id'];
		validateInt($id);
	}
	else
	{
		redirect ('emotionsbg.php');
	}
$table = '<center><table class="borders"><tr><th colspan="2"><b><center>THE LAST STEP:
<br>WHAT IS YOUR AGE?</br></center></b></th></tr>';
for($i = 0; $i<AGE_NUMBER; $i++){	
			//$table .= '<tr><td colspan="2" align="left"><br><input id="np" type="radio" name="choice" value="1"><label for="np">YEAR</label></br>';
			$table .= '<td class="slider_text"></td>';
			$table .= '<input type="hidden" value="1" name="e_slider_'.$i.'"/>';
			$table .= '<td><input type="range" name="e_slider_'.$i.'" class="e_slider" value="1" min="0" max="100" step="1" onchange="showNums()"/></td>';
			$table .= '<td><p align="center"><input type="submit" value="END"/></p></td>';
			$table .= '</tr>';
}
echo '<input type="hidden" name="id" value="'.$id.'">';

//$table .= '<p align="center"><input type="submit" value="КРАЙ"/></p>';
echo $table;
require_once('js/numbers.js');
//echo '<script src="js/refreshBack.js"></script>';
//echo '<script>refreshBack("emotionsbg.php")</script>';
require "end1.php";
?>