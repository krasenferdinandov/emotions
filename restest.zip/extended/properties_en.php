<?php
require "header.php";
echo '<table class="borders">';
echo '<tr><th>Id</th>';
function interval_to_duration ($interval) {
	return ($interval->h*60 + $interval->i + (floatval($interval->s) / 60));
}
function to_minutes ($duration) {
	return floor($duration) + ($duration - floor($duration)) * 60 / 100;
}
function ed ($category, $total)
{
	if($category>0 && $total > 0)
		return -1*($category/$total)*log($category/$total);
	else
		return 0;
}
function isInDomain($emotion_search){
	return (floor($emotion_search));
}
$string = array();
$domain = array();
$emotions = array();

$label = $pdo->query("SELECT id, en_name, bg_name FROM emotions");
while($row = $label->fetch(PDO::FETCH_BOTH))
{
	$bg_name = $row['en_name'];
	$emotions[$row['id']] ='<a title="'.quot($row['bg_name']).'">'. $bg_name.'</a>';
}

$statement = $pdo->query("SELECT id, string_id FROM emotions");
while($row = $statement->fetch(PDO::FETCH_BOTH))
{
	$string[$row['id']] = $row['string_id'];
		
}

$statement1 = $pdo->query("SELECT * FROM domains s, emotions sc WHERE sc.domain_id = s.id ");
while($row = $statement1->fetch(PDO::FETCH_BOTH))
{
	$domain[$row['id']] = $row['domain_id'];
	
}
for($i=0;$i<DOMAINS_NUMBER;$i++){
	$domain_data = $pdo->query("select en_name, bg_name from domains where id = ". $i . "");
	
	$name = "WRONG";
	while($r = $domain_data->fetch(PDO::FETCH_BOTH))
	{
		$en_name = $r["en_name"];
		$bg_name = $r["bg_name"];
	}
	//echo '<td><center>D'.$i.', '.$en_name.', '.$bg_name.'</center></td>';
	//echo '<td><center>F'.$i.'_'.$en_name.'</center></td>';
	//echo '<td><center>F'.$i.'</center></td>';
}
//------------------>
for($i=0;$i<THEMES_NUMBER;$i++){
	$script_data = $pdo->query("select en_name, bg_name from statements where id = ". $i . "");
		
	$name = "WTF";
	while($r = $script_data->fetch(PDO::FETCH_BOTH))
	{
		$en_name = $r["en_name"];
		$bg_name = $r["bg_name"];
	}
    //echo '<td><center>T'.$i.'_'.$en_name.'</center></td>';
	//echo '<td><center>T'.$i.'</center></td>';
}
for($i=0;$i<MINISCRIPTS_NUMBER;$i++){
	$miniscript_data = $pdo->query("select en_name, bg_name from miniscripts where id = ". $i . "");
		
	$name = "WTF";
	while($r = $miniscript_data->fetch(PDO::FETCH_BOTH))
	{
		$en_name = $r["en_name"];
		$bg_name = $r["bg_name"];
	}
	//echo '<td><center>S'.$i.', '.$en_name.'</center></td>';
	//echo '<td><center>S'.$i.', '.$en_name.', '.$bg_name.'</center></td>';
	//echo '<td><center>S'.$i.'</center></td>';
}
for($i=0;$i<STATES_NUMBER;$i++){
	$script_data = $pdo->query("select en_name, bg_name, axis_id from gros where id = ". $i . "");
		
	$name = "WTF";
	while($r = $script_data->fetch(PDO::FETCH_BOTH))
	{
		$en_name = $r["en_name"];
		$bg_name = $r["bg_name"];
		$axis = $r["axis_id"];
		
		if ($axis == 19){			
		$label= "S";
		}
		else 
		{
		$label= "R";
		}
	}
	//echo '<td><center>'.$label.''.$i.'</center></td>';
}
echo '<td><center><b>1. Number of recognized facial expressions (Ekman & Friesen, 1975)</b></center></td>';
echo '<td><center><b>1.1 Expression recognition response latency (Bassili, 1996)</b></center></td>';
echo '<td><center><b>2.1 Total emotional families selected (Ferdinandov, 2018)</b></center></td>';
echo '<td><center><b>2.1.1 Emotional families selection response latency (Ferdinandov, 2018)</b></center></td>';
echo '<td><center><b>2.2 Number of positive families (Ferdinandov, 2018)</b></center></td>';
echo '<td><center><b>2.2.1 Positive families selection response latency (Bassili, 1996)</b></center></td>';
echo '<td><center><b>2.3 Number of negative families (Ferdinandov, 2018)</b></center></td>';
echo '<td><center><b>2.3.1 Negative families selection response latency (Bassili, 1996)</b></center></td>';
echo '<td><center><b>2.4 Mean duration of total families selected (Bassili, 1996)</b></center></td>';
echo '<td><center><b>2.4.1 Mean duration of positive families selected (Bassili, 1996)</b></center></td>';
echo '<td><center><b>2.4.2 Mean duration of negative families selected (Bassili, 1996)</b></center></td>';
echo '<td><center><b>3. Number of associated themes (Demorest, 2008)</b></center></td>';
echo '<td><center><b>3.1 Themes association response latency (Bassili, 1996)</b></center></td>';
echo '<td><center><b>4. Number of associated scripts (Tomkins, 1978)</b></center></td>';
echo '<td><center><b>4.1 Scripts association response latency (Bassili, 1996)</b></center></td>';
echo '<td><center><b>5. Suppression regulation, points (Gross & John, 2003)</b></center></td>';
echo '<td><center><b>6. Reapprisal regulation, points (Gross & John, 2003)</b></center></td>';
echo '<td><center><b>6.1 Number of regulations statements identified (Gross & John, 2003)</b></center></td>';
echo '<td><center><b>6.2 Regulations appraisal response latency (Bassili, 1996)</b></center></td>';
echo '<td><center><b>7. Responce latency (Bassili, 1996)</b><center></td>';
echo '<td><center><b>8. Identifications availability (Bousfield & Sedgwick, 1944)</b><center></td>';
echo '<td><center><b>9. Level of frustration (Brown & Farber, 1951)</b><center></td>';
echo '<td><center><b>9.1 Level of frustration (Brown & Farber, 1951)</b><center></td>';
echo '<td><center><b>10. Affective differentiation (Scott, 1966)</b><center></td>';
echo '<td><center><b>10.1 Affective differentiation (Scott, 1969)</b><center></td>';
echo '<td><center><b>11. Objective ambivalence (Scott, 1966)</b><center></td>';
echo '<td><center><b>11.1 Objective ambivalence (Scott, 1966)</b><center></td>';
echo '<td><center><b>12. Affective balance (Bradburn, 1969)</b><center></td>';
echo '<td><center><b>12.1  Affective balance (Bradburn, 1969)</b><center></td>';
echo '<td><center><b>13. Level of avvective conflicts (Kaplan, 1972)</b><center></td>';
echo '<td><center><b>13.1 Level of affective conflicts (Kaplan, 1972)</b><center></td>';
echo '<td><center><b>14. Subjective ambivalence (Katz et al., 1986)</b><center></td>';
echo '<td><center><b>15. Potential ambivalence (Thompson et al., 1995)</b><center></td>';
echo '<td><center><b>15.1 Affective similarities (Thompson et al., 1995)</b><center></td>';
echo '<td><center><b>15.2 Affective extremity (Thompson et al., 1995)</b><center></td>';
echo '<td><center><b>15.1.1 Potential ambivalence (Thompson et al., 1995)</b><center></td>';
echo '<td><center><b>15.1.2 Affective similarities (Thompson et al., 1995)</b><center></td>';
echo '<td><center><b>15.1.3 Affective extremity (Thompson et al., 1995)</b><center></td>';
echo '<td><center><b>16. Frustration threshold, gradient (Priester & Petty, 1996)</b><center></td>';
echo '<td><center><b>16.1 Frustration threshold, gradient (Priester & Petty, 1996)</b><center></td>';
echo '<td><center><b>17. Frustration threshold, abrupt (Priester & Petty 1996)</b><center></td>';
echo '<td><center><b>17.1 Frustration threshold, abrupt (Priester & Petty 1996)</b><center></td>';
echo '<td><center><b>18. Ambivalence response (Choi & Choi, 2002)</b><center></td>';
echo '<td><center><b>18.1 Ambivalence response(Choi & Choi, 2002)</b><center></td>';
echo '<td><center><b>19. State of mind proportionality (Schwartz et al. 2002)</b><center></td>';
echo '<td><center><b>19.1 State of mind proportionality (Schwartz et al. 2002)</b><center></td>';
echo '<td><center><b>20. Index of misery (Juster et al. 1985, Kahneman et al. 2006)</b><center></td>';
echo '<td><center><b>21. Emotional well-being (Larsen 2009)</b><center></td>';
echo '<td><center><b>21.1 Emotional well-being (Larsen, 2009)</b><center></td>';
echo '<td><center><b>22. Mixed feelings (Kruger, 2009)</b><center></td>';
echo '<td><center><b>23. Mixed feelings (Larsen & Harshfield, 2009)</b><center></td>';
echo '<td><center><b>24. Mixed emotions (Podoynitsyna et al., 2012)</b><center></td>';
echo '<td><center><b>25. Total emotional diversity (Quoidbach et al. 2014)</b><center></td>';
echo '<td><center><b>25.1 Positive emotional diversity (Quoidbach et al. 2014)</b><center></td>';
echo '<td><center><b>25.2 Negative emotional diversity (Quoidbach et al. 2014)</b><center></td>';

//----------------------------------->
//echo '<td><center><b>5.1 Регулация чрез потискане, брой (Gross & John 2003)</b></center></td>';
//echo '<td><center><b>6.1 Регулация чрез преоценка, брой (Gross & John 2003)</b></center></td>';
//echo '<td><center><b>7. Ниво на импулсивността (Tomkins 1979-1987, Фердинандов и Бардов 2017)</b></center></td>';
//echo '<td><center><b>Начало</b><center></td>';
//echo '<td><center><b>Край</b><center></td>';
//echo '<td><center><b>Общо време (H:i:s)</b><center></td>';
//echo '<td><center><b>23. Претеглена несигурност (Kahneman & Tversky 1972)</b><center></td>';
//echo '<td><center><b>24. Обичаен афективен проспект (Kahneman & Tversky 1979)</b><center></td>';
//----------------------------------->

echo '</tr>';

$count_data = $pdo->query("SELECT id FROM states_stat ORDER BY id");

$count = 0;
$last = -1;
$id_array = array();
while($r = $count_data->fetch(PDO::FETCH_BOTH))
{
	if($r['id'] != $last)
	{
		$last = $r['id'];
		$id_array[] = $last;
		$count++;
	}
}

for($k = 0; $k<$count; $k++)
{ 
	$current_id = $id_array[$k];
	$emotion_row_array = array();
	$domain_row_array = array();
	$miniscripts_row_array = array();
	$scripts_row_array = array();

$data = $pdo->query("SELECT * FROM gros_stat WHERE id = $current_id LIMIT 1");	
//$data = $pdo->query("SELECT * FROM emotions_stat WHERE id = $current_id LIMIT 1");
//$data = $pdo->query("SELECT * FROM id_stat WHERE id = $current_id LIMIT 1");
//$data = $pdo->query("SELECT * FROM states_stat WHERE id = $current_id LIMIT 1");
//$data = $pdo->query("SELECT * FROM status_stat WHERE id = $current_id LIMIT 1");

$r = $data->fetch(PDO::FETCH_BOTH);
$id = $r['id'];
if(!isset($id)) continue;
	for($i = 0; $i<EMOTIONS_NUMBER; $i++)
	{
		$emotion_row_array[] = 0;
	}
	$domains_category_array ['pos'] = array();
	$domains_category_array ['neg'] = array();
	for($i = 0; $i<DOMAINS_NUMBER; $i++)
	{
		$domain_row_array[] = 0;
		$domains_category_array ['pos'][] = 0;
		$domains_category_array ['neg'][] = 0;
	}
	for($i = 0; $i<THEMES_NUMBER; $i++)
	{
		$scripts_row_array[] = 0;
	}
	for($i = 0; $i<MINISCRIPTS_NUMBER; $i++)
	{
		$miniscripts_row_array[] = 0;
	}
	$count_e=0;	
	$data = $pdo->query("SELECT emotion_id FROM emotions_stat WHERE id = $current_id");
	while($r = $data->fetch(PDO::FETCH_BOTH)) {
			
		$e_id = $r['emotion_id'];
		if($e_id!=-1) $emotion_row_array[$e_id] = 1;
		if($e_id != -1)$domain_row_array[$domain[$e_id]] = 1;
		
		$count_e+=1;
	}
$data = $pdo->query("SELECT * FROM gros_stat WHERE id = $current_id LIMIT 1");
$r = $data->fetch(PDO::FETCH_BOTH);
$id = $r['id'];
if(!isset($id)) continue;
	for($i = 0; $i<STATES_NUMBER; $i++)
	{
		$scripts_row_array[] = 0;
	}	
	
	$count_s=0;	
	$data_s = $pdo->query("SELECT * FROM states_stat WHERE id = $current_id");
	while($r = $data_s->fetch(PDO::FETCH_BOTH)) {
		$si_id = $r['state_id'];
				
		if($si_id!=-1) $scripts_row_array[$si_id] = 1;
		$count_s+=1;
	}
	
	$count_m=0;	
	$data = $pdo->query("SELECT miniscript_id FROM miniscripts_stat WHERE id = $current_id");
	while($r = $data->fetch(PDO::FETCH_BOTH)) {
		$mi_id = $r['miniscript_id'];
		if($mi_id!=-1) $miniscripts_row_array[$mi_id] = 1;
		$count_m+=1;
	}
//------------------------>
$posi = '';
$nega = '';
$manag = 0;
$sum_pos=0;$count_pos=0;
$sum_neg=0;$count_neg=0;
$sel_emotions = $pdo->query("SELECT * FROM emotions_stat WHERE id=$current_id");
while($r = $sel_emotions->fetch(PDO::FETCH_BOTH)){
	$e_id=$r['emotion_id'];
	$e_sl=$r['e_slider'];
	
	$data = $pdo->query("SELECT domain_id, valence_id, string_id, tension_id FROM emotions WHERE id = $e_id LIMIT 1");
	$r = $data->fetch(PDO::FETCH_BOTH);
	$domain_id = intval($r['domain_id']);
	$dimension_id = $r['valence_id'];
	$e_string = $r['string_id'];
	$e_tension = $r['tension_id'];
	
		if ($e_string == 0){			
		$density= (($e_sl*0.4)+$e_tension);
		}
		else if($e_string == 1){
		$density=(($e_sl*0.6)+$e_tension);
		}
		else if($e_string == 2){
		$density=(($e_sl*0.8)+$e_tension);
		}
		
		if($dimension_id == 0){
			$sum_pos+=$e_sl;
			//$sum_pos+=$density;
			$count_pos+=1;
		}
		if($dimension_id == 1){
			$sum_neg+=$e_sl;
			//$sum_neg+=$density;
			$count_neg+=1;
		}
}		
$score_neg=scores_level($sum_neg, $count_neg);
$score_pos=scores_level($sum_pos, $count_pos);
$score_group=$score_neg.$score_pos;

$data = $pdo->query("SELECT id,bg_name,bg_desc FROM management WHERE score_group LIKE '%$score_group%'");
$r = $data->fetch(PDO::FETCH_BOTH);
$id_manag = 99;

if ($r){
	$id_manag = $r['id'];
	$bg_name = $r['bg_name'];
	$bg_desc = $r['bg_desc'];
}else{
	$bg_name='';
	$bg_desc='';
}
$posi = percent($sum_pos, $sum_pos+$sum_neg);
$nega = percent($sum_neg, $sum_pos+$sum_neg);

//---------------------------->
echo '<tr><td><center>'.$current_id.'</center></td>';

//---------------------------->
/*for($i=0;$i<DOMAINS_NUMBER;$i++)
		if($domain_row_array[$i] != 1)
			echo '<td><center>0</center></td>';
		else echo '<td><center><b>1<b/></center></td>';
for($i=0;$i<THEMES_NUMBER;$i++)
		if($scripts_row_array[$i] != 1)
			echo '<td><center>0</center></td>';
		else echo '<td><center><b>1<b/></center></td>';
		
for($i=0;$i<MINISCRIPTS_NUMBER;$i++)
		if($miniscripts_row_array[$i] != 1)
			echo '<td><center>0</center></td>';
		else echo '<td><center><b>1<b/></center></td>';
for($i=0;$i<STATES_NUMBER;$i++)
		if($scripts_row_array[$i] != 1)
			echo '<td><center>0</center></td>';
		/*else {
			$data_t = $pdo->query("SELECT * FROM gros_stat WHERE id = " . $current_id . "");
			while($rs = $data_t->fetch(PDO::FETCH_BOTH)) {
			$s_id = $rs['state_id'];
			if($s_id!=$i)continue;
			$s_sl = $rs['g_slider'];
			}
			echo '<td><center><b>'.$s_sl.'<b/></center></td>';
		}*/
		//else echo '<td><center><b>1<b/></center></td>';
//---------------------------->

$data = $pdo->query("SELECT emotion_id FROM emotions_stat WHERE id = $current_id");
	while($r = $data->fetch(PDO::FETCH_BOTH)) {
			
		$e_id = $r['emotion_id'];
		if($e_id!=-1) $emotion_row_array[$e_id] = 1;
		if($e_id != -1)$domain_row_array[$domain[$e_id]] = 1;
		
		{
			$emotion = $pdo->query("SELECT * FROM emotions WHERE id = $e_id")->fetch(PDO::FETCH_BOTH);
			if ($emotion['valence_id'] == 0)
				$domains_category_array ['pos'][$domain[$e_id]] = 1;
			else
				$domains_category_array ['neg'][$domain[$e_id]] = 1;
		}
	}
	$positives = array_sum($domains_category_array['pos']); 
	$negatives = array_sum($domains_category_array['neg']); 
	$count_e = array_sum($domain_row_array);

//---------------------------->
$count_p=0;	
	$data = $pdo->query("SELECT label FROM photoes_stat WHERE id = $current_id");
	while($r = $data->fetch(PDO::FETCH_BOTH)) {
		$p_id = $r['label'];
		if($p_id != "0") $count_p+=1;

	}
//---------------------------->

$max_photoes = "0000-00-00 00:00:00";
$min_photoes = "9999-99-99 99:99:99";

$data = $pdo->query("SELECT timing_label FROM photoes_stat WHERE id = $current_id");
while($r = $data->fetch(PDO::FETCH_BOTH))
{
	$time = $r['timing_label'];
	if ($time == '') continue;
	$min_photoes = min($min_photoes, $time);
	$max_photoes = max($max_photoes, $time);
}

$max_emotions = "0000-00-00 00:00:00";
$min_emotions = "9999-99-99 99:99:99";

$data = $pdo->query("SELECT timing FROM emotions_stat WHERE id = $current_id");
while($r = $data->fetch(PDO::FETCH_BOTH))
{
	$time = $r['timing'];
	if ($time == '') continue;
	$min_emotions = min($min_emotions, $time);
	$max_emotions = max($max_emotions, $time);
}

$max_emotions_pos = "0000-00-00 00:00:00";
$min_emotions_pos = "9999-99-99 99:99:99";
$max_emotions_neg = "0000-00-00 00:00:00";
$min_emotions_neg = "9999-99-99 99:99:99";
$data = $pdo->query("SELECT timing, valence_id FROM emotions t1 INNER JOIN emotions_stat t2 ON t1.id = t2.emotion_id WHERE t2.id = $current_id AND t1.valence_id = 0");
while($r = $data->fetch(PDO::FETCH_BOTH))
{
	$time = $r['timing'];
	if ($time == '') continue;
	$min_emotions_pos = min($min_emotions_pos, $time);
	$max_emotions_pos = max($max_emotions_pos, $time);
}
$data = $pdo->query("SELECT timing, valence_id FROM emotions t1 INNER JOIN emotions_stat t2 ON t1.id = t2.emotion_id WHERE t2.id = $current_id AND t1.valence_id = 1");
while($r = $data->fetch(PDO::FETCH_BOTH))
{
	$time = $r['timing'];
	if ($time == '') continue;
	$min_emotions_neg = min($min_emotions_neg, $time);
	$max_emotions_neg = max($max_emotions_neg, $time);
}

$max_states = "0000-00-00 00:00:00";
$min_states = "9999-99-99 99:99:99";

$data = $pdo->query("SELECT timing FROM states_stat WHERE id = $current_id");
while($r = $data->fetch(PDO::FETCH_BOTH))
{
	$time = $r['timing'];
	if ($time == '') continue;
	$min_states = min($min_states, $time);
	$max_states = max($max_states, $time);
}

$max_scripts = "0000-00-00 00:00:00";
$min_scripts = "9999-99-99 99:99:99";

$data = $pdo->query("SELECT time FROM miniscripts_stat WHERE id = $current_id");
while($r = $data->fetch(PDO::FETCH_BOTH))
{
	$time = $r['time'];
	if ($time == '') continue;
	$min_scripts = min($min_scripts, $time);
	$max_scripts = max($max_scripts, $time);
}
	
$max_scripts2 = "0000-00-00 00:00:00";
$min_scripts2 = "9999-99-99 99:99:99";

$data = $pdo->query("SELECT time FROM miniscripts2_stat WHERE id = $current_id");
while($r = $data->fetch(PDO::FETCH_BOTH))
{
	$time = $r['time'];
	if ($time == '') continue;
	$min_scripts2 = min($min_scripts2, $time);
	$max_scripts2 = max($max_scripts2, $time);
}

$max_gros = "0000-00-00 00:00:00";
$min_gros = "9999-99-99 99:99:99";

$data = $pdo->query("SELECT timing FROM gros_stat WHERE id = $current_id");
while($r = $data->fetch(PDO::FETCH_BOTH))
{
	$time = $r['timing'];
	if ($time == '') continue;
	$min_gros = min($min_gros, $time);
	$max_gros = max($max_gros, $time);
}
$duration_photoes = 0;
$duration_emotions = 0;
$duration_emotions_pos = 0;
$duration_emotions_neg = 0;
$duration_states = 0;
$duration_scripts = 0;
$duration_scripts2 = 0;
$duration_gros = 0;

//TODO: SELECT * FROM miniscripts_stat t1 INNER JOIN miniscripts2_stat t2 ON t1.id = t2.id WHERE t1.miniscript_id=t2.miniscript_id

try {
	$datetime1 = new DateTime($min_photoes);
	$datetime2 = new DateTime($max_photoes);
	$duration_photoes = interval_to_duration($datetime1->diff($datetime2));
	
}catch (Exception $ex) {}try{
	$datetime3 = new DateTime($min_emotions);
	$datetime4 = new DateTime($max_emotions);
	$duration_emotions = interval_to_duration($datetime3->diff($datetime4));
	
}catch (Exception $ex) {}try{
	$datetime5 = new DateTime($min_emotions_pos);
	$datetime6 = new DateTime($max_emotions_pos);
	$duration_emotions_pos = interval_to_duration($datetime5->diff($datetime6));
	
}catch (Exception $ex) {}try{
	$datetime7 = new DateTime($min_emotions_neg);
	$datetime8 = new DateTime($max_emotions_neg);
	$duration_emotions_neg = interval_to_duration($datetime7->diff($datetime8));
	
}catch (Exception $ex) {}try{
	$datetime9 = new DateTime($min_states);
	$datetime10 = new DateTime($max_states);
	$duration_states = interval_to_duration($datetime9->diff($datetime10));
	
}catch (Exception $ex) {}try{
	$datetime11 = new DateTime($min_scripts);
	$datetime12 = new DateTime($max_scripts);
	$duration_scripts = interval_to_duration($datetime11->diff($datetime12));
	
}catch (Exception $ex) {}try{
	$datetime13 = new DateTime($min_scripts2);
	$datetime14 = new DateTime($max_scripts2);
	$duration_scripts2 = interval_to_duration($datetime13->diff($datetime14));
	
}catch (Exception $ex) {}try{
	$datetime15 = new DateTime($min_gros);
	$datetime16 = new DateTime($max_gros);
	$duration_gros = interval_to_duration($datetime15->diff($datetime16));
}catch (Exception $ex) {}
$duration = $duration_photoes + $duration_emotions + $duration_states + $duration_scripts + $duration_scripts2 + $duration_gros;
$duration1 = $duration_emotions + $duration_states + $duration_scripts + $duration_scripts2 + $duration_gros;

//--------------------------->
/*if ($current_id == 662)
	{
		echo $min_photoes . '; ' . $max_photoes . '<br>';
		echo $min_states . '; ' . $max_states . '<br>';
		echo $min_scripts . '; ' . $max_scripts . '<br>';
		echo $min_gros . '; ' . $max_gros . '<br>';
		
		echo to_minutes ($duration) . '=' . $duration_photoes . '+' . $duration_emotions . '+' . $duration_states . '+' . $duration_scripts . '+' . $duration_scripts2 . '+' . $duration_gros . '<br><br>';
	}*/

/*$sel_emotions = $pdo->query("SELECT * FROM choice_stat WHERE id=$current_id LIMIT 1");
	while($r = $sel_emotions->fetch(PDO::FETCH_BOTH)){
		$start=$r['end'];
		
		$data = $pdo->query("SELECT time FROM miniscripts_stat WHERE id = $current_id LIMIT 1");
		$r = $data->fetch(PDO::FETCH_BOTH);
		$stress = $r['time'];	
		
		$data = $pdo->query("SELECT timing FROM gros_stat WHERE id = $current_id LIMIT 1");
		$r = $data->fetch(PDO::FETCH_BOTH);
		$end = $r['timing'];
	}

	$datetime1 = new DateTime($start);
	$datetime2 = new DateTime($stress);
	$datetime3 = new DateTime($end);

	if(isset($id)) {
		$interval = $datetime1->diff($datetime3);
	}
	else {
		$interval = $datetime1->diff($datetime2);
	}
	$duration = ($interval->h*60 + $interval->i + (floatval($interval->s) / 100));
	*/
//---------------------------->

$sum_sup=0;
$sum_reap=0;
$count_sup=0;
$count_reap=0;
$selection = $pdo->query("SELECT * FROM gros_stat WHERE id=$current_id");
while($r = $selection->fetch(PDO::FETCH_BOTH)){
	$g_id=$r['state_id'];
	$g_sl=$r['g_slider'];
	
	$data = $pdo->query("SELECT axis_id FROM gros WHERE id = $g_id LIMIT 1");
	$r = $data->fetch(PDO::FETCH_BOTH);
	$axis_id = $r['axis_id'];
			
		if($axis_id == 19){
			$sum_sup+=round (($g_sl/4), 1);
			$count_sup+=1;
		}
		if($axis_id == 20){
			$sum_reap+= round (($g_sl/6), 1);
			$count_reap+=1;
		}
}		
//---------------------------->

$ed_pos = 0;
$ed_neg = 0;
$ed_tot = 0;
for($J = 0; $J<DOMAINS_NUMBER; $J++)
{
	$ed_pos += ed ($domains_category_array ['pos'][$J], $positives);
	$ed_neg += ed ($domains_category_array ['neg'][$J], $negatives);
}
$ed_tot = $ed_pos + $ed_neg;

//---------------------------------------------------->

$string0 = to_minutes ($duration); 
$string0 = str_replace(".", ",", $string0); 
echo '<td><center>'.$string0.'</center></td>';// Време за участие, в минути.

$string1 = round ((1-exp(-1*to_minutes ($duration1)))/($count_p+$count_e), 3);
$string1 = str_replace(".", ",", $string1);
echo '<td><center>'.$string1.'</center></td>';// Достъпност на идентификациите (Bousfield & Sedgwick 1944)

$string2 = round ((($positives > 0) ? (floatval ($negatives*$negatives) / $positives) : 0), 1); 
$string2 = str_replace(".", ",", strval($string2));
echo '<td><center>'.$string2.'</center></td>';// Ниво на фрустрация (Brown & Farber 1951)

$string2_ = round ((($positives > 0) ? (floatval ($sum_neg*$sum_neg) / $sum_pos) : 0), 2); 
$string2_ = str_replace(".", ",", strval($string2_));
echo '<td><center>'.$string2_.'</center></td>';// Ниво на фрустрация (Brown & Farber 1951)

$string3 = round ((($count_e * log (1/$count_e, 2))/log (10, 2)), 2); 
$string3 = str_replace(".", ",", $string3);
echo '<td><center>'.$string3.'</center></td>';// Разграничаване на емоции (Scott 1966)

$string007_ = round ((log (10, 2) - (($count_e *log ($count_e, 2))/10)), 2);
$string007_ = str_replace(".", ",", $string007_);
echo '<td><center>'.$string007_.'</center></td>';// Сложност на афективните идентификации  (Scott 1966)

$string4_ = round ((2*$positives + 1) / ($positives + $negatives + 2), 2);
$string4_ = str_replace(".", ",", $string4_);
echo '<td><center>'.$string4_.'</center></td>';// Обективно двусмислие (Scott 1966)

$string4 = round ((2*$sum_pos + 1) / ($sum_pos + $sum_neg + 2), 2); 
$string4 = str_replace(".", ",", $string4);
echo '<td><center>'.$string4.'</center></td>';// Обективно двусмислие (Scott 1966)

$string25 = round ((($positives-$negatives)), 2); 
$string25 = str_replace(".", ",", $string25);
echo '<td><center>'.$string25.'</center></td>';// Афективен баланс (Bradburn 1969)

$string26_ = round ((($sum_pos-$sum_neg)), 2); 
$string26_ = str_replace(".", ",", $string26_);
echo '<td><center>'.$string26_.'</center></td>';// Афективен баланс (Bradburn 1969)

echo '<td><center>'.(($positives + $negatives) - abs($positives - $negatives)).'</center></td>'; // Ниво на конфликтите (Kaplan 1972)

echo '<td><center>'.(($sum_pos + $sum_neg) - abs($sum_pos - $sum_neg)).'</center></td>'; // Ниво на конфликтите (Kaplan 1972)

$string9 = round (($positives * $negatives), 2); 
$string9 = str_replace(".", ",", $string9);
echo '<td><center>'.$string9.'</center></td>';// Контрасти в амбивалентността (Katz 1986)

$string10 = round ((floatval($positives+$negatives)/2 -abs($positives-$negatives)), 2); 
$string10 = str_replace(".", ",", $string10);
echo '<td><center>'.$string10.'</center></td>';// Потенциално противоречие 1( Thompson et al. 1995)

$string11 = round (-abs($positives-$negatives), 2); 
$string11 = str_replace(".", ",", $string11);
echo '<td><center>'.$string11.'</center></td>';// а.1 Подобие между противоположни състояния (Thompson et al. 1995)

$string12 = round (floatval($positives+$negatives)/2, 2); 
$string12 = str_replace(".", ",", $string12);
echo '<td><center>'.$string12.'</center></td>';// б.1 Изразеност на противоречията(Thompson et al. 1995)

$string13 = round (((floatval($sum_pos+$sum_neg)/2) - abs($sum_pos-$sum_neg)), 2); 
$string13 = str_replace(".", ",", $string13);
echo '<td><center>'.$string13.'</center></td>';// Потенциално противоречие 2( Thompson et al. 1995)

$string14 = round (-abs($sum_pos-$sum_neg), 2); 
$string14 = str_replace(".", ",", $string14);
echo '<td><center>'.$string14.'</center></td>';// а.2 Подобие между противоположни състояния (Thompson et al. 1995)

$string15 = round (floatval($sum_pos+$sum_neg)/2, 2); 
$string15 = str_replace(".", ",", $string15);
echo '<td><center>'.$string15.'</center></td>';// б.2 Изразеност на противоречията(Thompson et al. 1995)

$string16 = round ((5*($negatives/2))/10, 2); 
$string16 = str_replace(".", ",", $string16);
echo '<td><center>'.$string16.'</center></td>';// Ниво на преживяна фрустрация, с градиращ праг (Priester & Petty 1996)

$string16_ = round ((5*($sum_neg/2))/100, 2); 
$string16_ = str_replace(".", ",", $string16_);
echo '<td><center>'.$string16_.'</center></td>';// Ниво на преживяна фрустрация, с градиращ праг (Priester & Petty 1996)

$string17 = round (($negatives > 0) ? (5 * ($negatives * (0.5 * $negatives)) - ($positives * $positives * 1.0 / $negatives)) / 10 : 0, 2); 
$string17 = str_replace(".", ",", $string17);
echo '<td><center>'.$string17.'</center></td>'; // Ниво на преживяна фрустрация, с рязък праг (Priester & Petty 1996)

$string17_ = round (($negatives > 0) ? (5 * ($sum_neg * (0.5 * $sum_neg)) - ($sum_pos * $sum_pos * 1.0 / $sum_neg)) / 10 : 0, 2); 
$string17_ = str_replace(".", ",", $string17_);
echo '<td><center>'.$string17_.'</center></td>'; // Ниво на преживяна фрустрация, с рязък праг (Priester & Petty 1996)

$string18 = round ((abs($positives-$negatives)), 2); 
$string18 = str_replace(".", ",", $string18);
echo '<td><center>'.$string18.'</center></td>';// Амбивалентна реакция (Choi & Choi 2002)

$string18_ = round ((abs($sum_pos-$sum_neg)), 2); 
$string18_ = str_replace(".", ",", $string18_);
echo '<td><center>'.$string18_.'</center></td>';// Амбивалентна реакция (Choi & Choi 2002)

$string19 = round (($positives / ($negatives+$positives)), 2); 
$string19 = str_replace(".", ",", $string19);
echo '<td><center>'.$string19.'</center></td>';// Пропорционалност в преценките (Schwartz 2002)

$string19_= round (($sum_pos / ($sum_neg+$sum_pos)), 2);
$string19_ = str_replace(".", ",", $string19_);
echo '<td><center>'.$string19_.'</center></td>';// Пропорционалност в преценките (Schwartz 2002)

$string24 = round (($negatives > $positives) ?(($sum_neg*$negatives)) :0 ,3);
$string24 = str_replace(".", ",", $string24);
echo '<td><center>'.$string24.'</center></td>';// б. Experienced misery (Juster et al. 1985, Kahneman et al. 2006)

$string20 = round (($negatives > 0) ? ($positives / ($negatives)) : 0, 2); 
$string20 = str_replace(".", ",", $string20);
echo '<td><center>'.$string20.'</center></td>';// Емоционално благополучие, без pi (Larsen 2009)

$string20_ = round (($sum_neg > 0) ? ($sum_pos / ($sum_neg)) : 0, 2); 
$string20_ = str_replace(".", ",", $string20_);
echo '<td><center>'.$string20_.'</center></td>';// Емоционално благополучие, без pi (Larsen 2009)

$string27 = min(array(max(array($positives))+max(array($negatives)))); 
$string27 = str_replace(".", ",", $string27);
echo '<td><center>'.$string27.'</center></td>';// Смесени чувства (Kruger 2009)

$string29 = min(array($positives/5 + $negatives/5)); 
$string29 = str_replace(".", ",", $string29);
echo '<td><center>'.$string29.'</center></td>';// Смесени чувства (Larsen & Hershfield 2012)

$string30 = round (($negatives > 0) ? min(array($positives / ($negatives))) : 0, 2); 
$string30 = str_replace(".", ",", $string30);
echo '<td><center>'.$string30.'</center></td>';// Смесени емоции (Podoynitsyna et al.  2012)

$string21 = round (($ed_tot), 2); 
$string21 = str_replace(".", ",", $string21);
echo '<td><center>'.$string21.'</center></td>';// Общо емоционално разнообразие (Quoidbach et al. 2014)

$string22 = round (($ed_pos), 2); 
$string22 = str_replace(".", ",", $string22);
echo '<td><center>'.$string22.'</center></td>';// а. Разнообразие в положителните състояния (Quoidbach et al. 2014)

$string23 = round (($ed_neg), 2); 
$string23 = str_replace(".", ",", $string23);
echo '<td><center>'.$string23.'</center></td>';// б. Разнообразие в отрицателните състояния (Quoidbach et al. 2014)

//---------------------------------------->

//$string1 = round ((1-exp(-1*to_minutes ($duration1)))/($count_p+$count_e+$count_s+$count_m+$count_sup+$count_reap), 3);

//$string19 = round (($negatives / ($negatives+$positives)), 2); 
//$string19_= round (($sum_neg / ($sum_neg+$sum_pos)), 2); 

//$string1 = round ((1-exp(-1*to_minutes ($duration_emotions)))/($count_e), 3);
//$string3 = round ((($count_e/10 * log (1/$count_e/10, 2))/log (10, 2)), 2);

//$string20 = round (($negatives > 0) ? ($positives / (pi () * $negatives)) : 0, 2); // Емоционално благополучие, с pi (Larsen 2008)
//$string20 = round (($negatives > 0) ? ($positives / (pi () * $negatives)) : 0, 2); // Емоционално благополучие, с pi (Larsen 2008)

/* = round (($count_sup > 0) ? ($sum_sup / $count_sup) : 0, 1); 
$string0 = str_replace(".", ",", $string0);
echo '<td><center>'.$string0.'</center></td>';*/

/*$string01 = round (($count_reap > 0) ? ($sum_reap / $count_reap) : 0, 1); 
$string01 = str_replace(".", ",", $string01);
echo '<td><center>'.$string01.'</center></td>';*/

//echo '<td><center>'.$sum_sup.'</center></td>';
//echo '<td><center>'.$sum_reap.'</center></td

//echo '<td><center>'.$count_sup.'</center></td>';//Регулация чрез потискане (Gross & John 2003)
//echo '<td><center>'.$count_reap.'</center></td>';//Регулация чрез преоценка (Gross & John 2003)
//echo '<td><center>'.$id_manag.'</center></td>';//Ниво на импулсивността (Tomkins 1979-1987, Фердинандов и Бардов 2017)

//echo '<td><center>'.$start.'</center></td>';
//echo '<td><center>'.$end.'</center></td>';
//echo '<td><center>'.$interval->format('%H:%i:%s').'</center></td>';

//$string24 = round (($negatives > $positives) ?(($sum_neg*$negatives)/100) : (-1*($sum_neg*$negatives)/100) ,3);
//$string24 = round (($negatives > $positives) ?(($sum_neg*$negatives/($negatives - $positives))/100) :0 ,3);
//$string24 = round (($negatives > $positives) ?(($sum_neg*($negatives + $positives)/($negatives - $positives))/100) :0 ,3);
//$string24 = round (($negatives > $positives) ?(($duration_emotions_neg*$sum_neg)/100) :0 ,3);
//$string24 = round (($sum_neg > $sum_pos) ?(($duration_emotions_neg*$sum_neg)/100) :0 ,3);

/*$string25 = round (($negatives > $positives) ?(($sum_neg*$negatives/($negatives - $positives))/100) :0 ,3);
$string25 = str_replace(".", ",", $string25);
echo '<td><center>'.$string25.'</center></td>';// б. Misery index (Ferdinandov 2019)

$string5 = round ((($positives/10)/(1-($positives/10)))*((($positives/10)/(1-($positives/10)))*($positives - $negatives)), 2); 
$string5 = str_replace(".", ",", $string5);
echo '<td><center>'.$string5.'</center></td>'; // Претеглен шанс (Kahneman & Tversky 1972)

$string6 = round (($negatives > 0 && $positives > 0) ? (($positives/($positives+$negatives))*($sum_pos/($positives*10)) + ($negatives/($positives+$negatives))*($sum_neg/($negatives*10))) :  0 ,2);
$string6 = str_replace(".", ",", ""+$string6);
echo '<td><center>'.$string6.'</center></td>';// Обичаен проспект (Tversky & Kahneman 1979, Ferdinandov 2018)

$string6 = round (($negatives > 0 && $positives > 0 && $negatives > $positives) ? ($sum_pos + (($negatives/$positives+$negatives)*($sum_neg - $sum_pos)))/100 :  0 ,2);
$string6 = str_replace(".", ",", ""+$string6);
echo '<td><center>'.$string6.'</center></td>';// Негативен проспект (Tversky & Kahneman 1981, Ferdinandov 2018)

$string7 = round (($positives > 0) ?($positives/($positives+$negatives))*($sum_pos/($positives*10)) :0 ,2);
$string7 = str_replace(".", ",", $string7);
echo '<td><center>'.$string7.'</center></td>';// Positives prospect (Tversky & Kahneman 1981, Ferdinandov 2018)

$string8 = round (($negatives > 0) ?($negatives/($positives+$negatives))*($sum_neg/($negatives*10)) :0 ,2);
$string8 = str_replace(".", ",", $string8);
echo '<td><center>'.$string8.'</center></td>';// Negatives prospect (Tversky & Kahneman 1981, Ferdinandov 2018)*/
//---------------------------------------->

echo '</tr>';
}
echo '</table>';
require "end.php";
?>