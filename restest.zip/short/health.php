<?php
require "headerbg1.php";
echo '<form id="the_form" method="POST" action="intodb7.php" enctype="multipart/form-data" onSubmit="return checkboxesOkay(this);">';
if (array_key_exists('id', $_GET))
	{
		$id = $_GET['id'];
		validateInt($id);
	}
	else
	{
		redirect ('emotionsbg.php');
	}
$table = '<center><table class="borders"><tr><th colspan="2"><b><center>THE FIFTH STEP:
<br>DEFINE YOUR MENTAL HEALTH</br></center></b></th></tr>';
for ($i = 1 ; $i <= CHOICE_NUMBER; $i ++) {
	$to_add = true;
		if (''.$i == '0')
		{
			$to_add = false;
			break;
		}
		if ($to_add)
		{
			if ($i == '1') {
			$table .= '<tr><td colspan="2" align="left"><br><input id="np" type="radio" name="choice" value="1">
			<label for="np">NO COMPLAINS</label></br>';
			}
			if ($i == '2') {
				$table .= '<tr><td colspan="2" align="left"><br><input id="disturbed" type="radio" name="choice" value="2">
				<label for="disturbed">DISTURBED.</label></br>';
			}
		}
		
}
$table .= '<p align="center"><input type="submit" value="NEXT"/></p>';
echo '<input type="hidden" name="id" value="'.$id.'">';
$table .= '</tr>';
echo $table;
//echo '<script src="js/refreshBack.js"></script>';
//echo '<script>refreshBack("emotionsbg.php")</script>';
require "end1.php";
?>